<?php
session_start();
include 'conexion.php'; // Conexión a la base de datos

// Solo permitir acceso si el usuario es administrador y no gestor
if ($_SESSION['rol'] !== 'administrador' || $_SESSION['es_gestor']) {
    die("<p style='font-size: 3rem; font-weight: bold;'>No tiene permiso para acceder a esta sección</p>");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Recoger datos del formulario
    $nombre = trim($_POST['nombre']);
    $apellidos = trim($_POST['apellidos']);
    $dni = trim($_POST['dni']);
    $email = trim($_POST['email']);
    $titulacion_gestor = trim($_POST['titulacion_gestor']);
    $es_camionero = isset($_POST['es_camionero']);

    // Obtener el admin_id del usuario administrador
    $admin_id = $_SESSION['usuario_id'];

    // Crear token de verificación
    $token_verificacion = bin2hex(random_bytes(32));
    $expiracion_token = date('Y-m-d H:i:s', strtotime('+48 hours'));
    $contrasena_temporal = password_hash('cambiar123', PASSWORD_DEFAULT);

    // Insertar gestor en tabla usuarios
    include 'conexion.php';
    $stmt = $conn->prepare("INSERT INTO usuarios (nombre_usuario, apellidos, email, dni, rol, admin_id, estado, titulacion_gestor, token_verificacion, expiracion_token, contrasena) VALUES (?, ?, ?, ?, 'gestor', ?, 'activo', ?, ?, DATE_ADD(NOW(), INTERVAL 48 HOUR), ?)");
    $stmt->bind_param("ssssssssss", $nombre_usuario, $apellidos, $email, $dni, $rol, $admin_id, $estado, $titulacion_gestor, $token_verificacion, $expiracion_token, $contrasena);

    $nombre_usuario = trim($_POST['nombre']);
    $token_verificacion = bin2hex(random_bytes(16));
    $expiracion_token = date("Y-m-d H:i:s", strtotime('+48 hours'));
    $estado = 'activo';
    $contrasena = password_hash('InterTrucker2025', PASSWORD_DEFAULT); // contraseña provisional

    if ($stmt->execute()) {
        $usuario_id = $stmt->insert_id;

        if ($es_camionero) {
            // Si además es camionero, insertamos en tabla camioneros con datos vacíos por defecto
            $stmt_camionero = $conn->prepare("INSERT INTO camioneros (usuario_id, tipo_carnet, num_licencia, activo) VALUES (?, '', '', 1)");
            $stmt_camionero->bind_param("i", $usuario_id);
            $stmt_camionero->execute();
            $stmt_camionero->close();
        }

        // Preparar email
        $enlace_verificacion = "https://intertrucker.net/registro_gestor.php?token=" . $token_verificacion;
        $asunto = "Completa tu registro como Gestor en InterTrucker";
        $mensaje = "Hola $nombre_usuario,\n\nHas sido dado de alta como gestor en InterTrucker.";
        if ($es_camionero) {
            $mensaje .= "\nAdemás se ha activado tu perfil de camionero.";
        }
        $mensaje .= "\n\nTu titulación registrada es: $titulacion_gestor\n\nCompleta tu registro en el siguiente enlace: $enlace_verificacion";

        // Enviar email
        $headers = "From: no-reply@intertrucker.net";
        if (mail($email, $asunto, $mensaje, $headers)) {
            header("Location: gestinar_colaboradores.php?message=Gestor añadido y correo enviado.");
            exit();
        } else {
            echo "Error al enviar correo.";
        }
    } else {
        header("Location: gestinar_colaboradores.php?message=Gestor añadido correctamente (sin rol camionero)");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Añadir Gestor</title>
</head>
<body>
<h1>Agregar Gestor</h1>
<form method="POST">
    <label>Nombre:</label>
    <input type="text" name="nombre" required><br>

    <label>Apellidos:</label>
    <input type="text" name="apellidos" required><br>

    <label>DNI:</label>
    <input type="text" name="dni" required><br>

    <label>Email:</label>
    <input type="email" name="email" required><br>

    <label>Titulación como Gestor:</label>
    <input type="text" name="titulacion_gestor" required><br>

    <label>¿También será camionero?</label>
    <input type="checkbox" name="es_camionero"><br>

    <button type="submit">Añadir Gestor y Enviar Enlace</button>
</form>
</body>
</html>
