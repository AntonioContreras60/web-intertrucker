<?php
session_start();
include 'conexion.php'; // Ajusta el nombre de tu archivo de conexión
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Verificar que exista usuario_id en la sesión:
if (!isset($_SESSION['usuario_id'])) {
    die("Error: Falta usuario_id en la sesión.");
}
$usuarioSesion = $_SESSION['usuario_id'];

// Construimos la query para extraer:
// - empresa_id = so.usuario_id (a quién le asignaste el porte)
// - u.nombre_empresa = nombre de la empresa
// - la cuenta de portes (COUNT(*)) que tengan fecha_entrega >= hoy
$sql = "
    SELECT 
      so.usuario_id AS empresa_id,
      u.nombre_empresa AS empresa_nombre,
      COUNT(*) AS total_portes
    FROM seleccionados_oferta so
    JOIN portes p ON so.porte_id = p.id
    JOIN usuarios u ON so.usuario_id = u.id
    WHERE so.ofertante_id = ?
      AND p.fecha_entrega >= CURDATE()
    GROUP BY so.usuario_id
    ORDER BY u.nombre_empresa ASC
";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    die('Error preparando la consulta: '.$conn->error);
}
$stmt->bind_param("i", $usuarioSesion);
$stmt->execute();
$res = $stmt->get_result();

$empresas = [];
while ($row = $res->fetch_assoc()) {
    $empresas[] = $row;
}
$stmt->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Empresas Asignadas</title>
  <style>
    body {
      font-family: Arial, sans-serif; 
      margin: 0;
      padding: 16px;
    }
    table {
      border-collapse: collapse;
      width: 100%;
      margin-top: 16px;
    }
    th, td {
      border: 1px solid #ccc; 
      padding: 8px;
    }
    th {
      background-color: #f2f2f2;
    }
    .btn {
      display: inline-block;
      padding: 8px 12px;
      background: #007bff;
      color: #fff;
      text-decoration: none;
      border-radius: 4px;
    }
  </style>
</head>
<body>

<!-- Header -->
<?php include 'header.php'; ?>

<h1>Empresas / Transportistas a los que he asignado portes</h1>

<?php if (count($empresas) > 0): ?>
  <table>
    <thead>
      <tr>
        <th>ID</th>
        <th>Empresa / Transportista</th>
        <th>Nº Portes sin finalizar</th>
        <th>Acción</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($empresas as $e): ?>
      <tr>
        <td><?php echo htmlspecialchars($e['empresa_id']); ?></td>
        <td><?php echo htmlspecialchars($e['empresa_nombre']); ?></td>
        <td><?php echo htmlspecialchars($e['total_portes']); ?></td>
        <td>
          <!-- Botón para ver el detalle de portes. 
               “usuario_id= X” => en portes_cedidos_empresa.php
               filtras so.usuario_id = X y so.ofertante_id = tu ID 
               AND p.fecha_entrega >= CURDATE(). -->
          <a href="portes_cedidos_empresa.php?usuario_id=<?php echo $e['empresa_id']; ?>" 
             class="btn">
            Ver portes
          </a>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
<?php else: ?>
  <p>No hay empresas con portes asignados que tengan fecha de entrega pendiente (>= hoy).</p>
<?php endif; ?>

<!-- Footer -->

</body>
</html>
