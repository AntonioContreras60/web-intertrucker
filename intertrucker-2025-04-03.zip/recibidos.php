<?php
session_start();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portes Recibidos - InterTrucker</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <!-- Incluir el menú de navegación -->
    <?php include 'header.php'; ?>
    
    <main>
        <a href="inter.php" class="button">INTER</a>
        <h1>Portes Recibidos</h1>
        
        <table>
            <thead>
                <tr>
                    <th>ID Porte</th>
                    <th>Cliente</th>
                    <th>Origen</th>
                    <th>Fecha Entrega</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php
                include 'conexion.php';
                $sql = "SELECT idPrimaria, cliente_id, localizacion_recogida, fecha_entrega FROM portes WHERE tipo_carga = 'Recibido'";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>
                                <td>{$row['idPrimaria']}</td>
                                <td>{$row['cliente_id']}</td>
                                <td>{$row['localizacion_recogida']}</td>
                                <td>{$row['fecha_entrega']}</td>
                                <td><a href='detalle_porte.php?id={$row['idPrimaria']}'>Ver Detalles</a></td>
                              </tr>";
                    }
                } else {
                    echo "<tr><td colspan='5'>No se encontraron portes recibidos.</td></tr>";
                }

                $conn->close();
                ?>
            </tbody>
        </table>
    </main>

    <!-- Incluir el pie de página -->
    <?php include 'footer.php'; ?>
</body>
</html>
