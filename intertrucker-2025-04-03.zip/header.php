<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Header InterTrucker</title>
    <style>
        /* Estilo general del header */
        header {
            background-color: #001c7d;
            display: flex;
            align-items: center;
            justify-content: space-between;
            /* Ajusta la altura mínima */
            min-height: 70px;
            /* Si deseas quitar cualquier límite de altura máxima, simplemente comenta o elimina esta línea */
            /* max-height: 200px; */
            /* Ajusta el padding para reducir o ampliar la distancia interior */
            padding: 5px 20px;
        }

        /* Estilo del botón (Menú, etc.) */
        button:hover {
            color: #ffc107;
        }

        /* Media query para ocultar solo la imagen del logo en pantallas pequeñas (por debajo de 600px) */
        @media (max-width: 600px) {
            #logo img {
                display: none;
            }
        }

        /*
         * NUEVA media query para ajustar el tamaño de letra en móviles
         * Con !important para que sobrescriba los estilos en línea.
         */
        @media (max-width: 600px) {
            button {
                font-size: 1.2em !important;
            }
            #menuDropdown a {
                font-size: 1.2em !important;
            }
        }
    </style>
</head>
<body>

<header style="background-color:#001c7d; display: flex; align-items: center; justify-content: space-between; padding: 0px 10px;">
    <nav style="display: flex; align-items: center; flex-wrap: wrap;">
        <!-- Botón desplegable Menú -->
        <div style="position: relative;">
            <!-- Ajusta el padding (vertical) para hacerlo más bajo -->
            <button onclick="toggleDropdown('menuDropdown')" 
                    style="padding: 10px 16px; 
                           background-color: rgba(0, 0, 0, 0.6); 
                           color: white; 
                           border-radius: 5px; 
                           font-weight: bold; 
                           font-size: 1em; /* Antes era 1.2em */ 
                           border: none;">
                Menú
            </button>

            <div id="menuDropdown" 
                 style="display: none; 
                        position: absolute; 
                        top: 100%; 
                        left: 0; 
                        background-color: #f1f1f1; 
                        min-width: 345px; 
                        box-shadow: 0px 8px 16px rgba(0,0,0,0.2); 
                        z-index: 9999; 
                        max-height: 70vh; 
                        overflow-y: auto;">
                <a href="/portes_nuevos_recibidos.php" 
                   style="display: block; 
                          padding: 16px 24px; 
                          color: black; 
                          font-size: 1em; /* Antes 1.5em */ 
                          text-decoration: none;">
                    <img src="/imagenes/iconos/paquete.svg" alt="Portes Nuevos" 
                         style="width: 24px; 
                                height: 24px; 
                                vertical-align: middle; 
                                margin-right: 12px;">
                    Portes Nuevos
                </a>
                <a href="/portes_cedidos.php" 
                   style="display: block; 
                          padding: 16px 24px; 
                          color: black; 
                          font-size: 1em; /* Antes 1.5em */ 
                          text-decoration: none;">
                    <img src="/imagenes/iconos/transferidos.svg" alt="Portes Transferidos" 
                         style="width: 24px; 
                                height: 24px; 
                                vertical-align: middle; 
                                margin-right: 12px;">
                    Portes Transferidos
                </a>
                <a href="/portes_trucks.php" 
                   style="display: block; 
                          padding: 16px 24px; 
                          color: black; 
                          font-size: 1em; /* Antes 1.5em */ 
                          text-decoration: none;">
                    <img src="/imagenes/iconos/portes_camiones.svg" alt="Portes a Camiones" 
                         style="width: 24px; 
                                height: 24px; 
                                vertical-align: middle; 
                                margin-right: 12px;">
                    Portes a Camiones
                </a>
                <a href="/listado_expedidor.php" 
                   style="display: block; 
                          padding: 16px 24px; 
                          color: black; 
                          font-size: 1em; /* Antes 1.2em */ 
                          text-decoration: none;">
                    <img src="/imagenes/iconos/package_truck_ramp.svg?v=1" alt="Expedidor Destinatario" 
                         style="width: 24px; 
                                height: 24px; 
                                vertical-align: middle; 
                                margin-right: 12px;">
                    Salida-Entrada Almacén
                </a>
                <a href="/facturas.php" 
                   style="display: block; 
                          padding: 16px 24px; 
                          color: black; 
                          font-size: 1em; /* Antes 1.2em */ 
                          text-decoration: none;">
                    <img src="/imagenes/iconos/facturas.svg" alt="Facturas" 
                         style="width: 24px; 
                                height: 24px; 
                                vertical-align: middle; 
                                margin-right: 12px;">
                    Facturas
                </a>
                <a href="/my_network.php" 
                   style="display: block; 
                          padding: 16px 24px; 
                          color: black; 
                          font-size: 1em; /* Antes 1.2em */ 
                          text-decoration: none;">
                    <img src="/imagenes/iconos/mis_contactos.svg" alt="Mis contactos" 
                         style="width: 24px; 
                                height: 24px; 
                                vertical-align: middle; 
                                margin-right: 12px;">
                    Mis contactos
                </a>
                <!--<a href="/gestionar_tren_camionero.php" 
                   style="display: block; 
                          padding: 16px 24px; 
                          color: black; 
                          font-size: 1em; /* Antes 1.2em */ 
                          text-decoration: none;">
                    <img src="/imagenes/iconos/portes_camiones.svg" alt="Portes a Camiones"
                         style="width: 24px; 
                                height: 24px; 
                                vertical-align: middle; 
                                margin-right: 12px;">
                    Tren-Conductor
                </a> -->
                <a href="/my_trucks.php" 
                   style="display: block; 
                          padding: 16px 24px; 
                          color: black; 
                          font-size: 1em; /* Antes 1.2em */ 
                          text-decoration: none;">
                    <img src="/imagenes/iconos/mis_vehiculos.svg" alt="Mis Vehículos" 
                         style="width: 24px; 
                                height: 24px; 
                                vertical-align: middle; 
                                margin-right: 12px;">
                    Mis Vehículos
                </a>
                <a href="/my_truckers.php" 
                   style="display: block; 
                          padding: 16px 24px; 
                          color: black; 
                          font-size: 1em; /* Antes 1.2em */ 
                          text-decoration: none;">
                    <img src="/imagenes/iconos/mis_conductores.svg" alt="Mis Conductores" 
                         style="width: 24px; 
                                height: 24px; 
                                vertical-align: middle; 
                                margin-right: 12px;">
                    Mis Conductores
                </a>
                <a href="/gestionar_colaboradores.php" 
                   style="display: block; 
                          padding: 16px 24px; 
                          color: black; 
                          font-size: 1em; /* Antes 1.2em */ 
                          text-decoration: none;">
                    <img src="/imagenes/iconos/icono_computador.svg" alt="Gestores" 
                         style="width: 24px; 
                                height: 24px; 
                                vertical-align: middle; 
                                margin-right: 12px;">
                   Mis Gestores
                </a>
                </a>
                <a href="/mis_asociados.php" 
                   style="display: block; 
                          padding: 16px 24px; 
                          color: black; 
                          font-size: 1em; /* Antes 1.2em */ 
                          text-decoration: none;">
                    <img src="/imagenes/iconos/mis_conductores.svg" alt="Mis Conductores" 
                         style="width: 24px; 
                                height: 24px; 
                                vertical-align: middle; 
                                margin-right: 12px;">
                    Mis Conductores Asociados
                </a>
                <a href="Perfil/perfil_usuario.php" 
                   style="display: block; 
                          padding: 16px 24px; 
                          color: black; 
                          font-size: 1em; /* Antes 1.2em */ 
                          text-decoration: none;">
                    <img src="/imagenes/iconos/perfil.svg" alt="Mi Perfil" 
                         style="width: 24px; 
                                height: 24px; 
                                vertical-align: middle; 
                                margin-right: 12px;">
                    Mi Perfil
                </a>
                <a href="Perfil/logout.php" 
                   style="display: block; 
                          padding: 16px 24px; 
                          color: black; 
                          font-size: 1em; /* Antes 1.2em */ 
                          text-decoration: none;">
                    <img src="/imagenes/iconos/cerrar_sesion.svg" alt="Cerrar sesión" 
                         style="width: 24px; 
                                height: 24px; 
                                vertical-align: middle; 
                                margin-right: 12px;">
                    Cerrar sesión
                </a>
            </div>
        </div>
    </nav>

    <!-- Espaciador para separar menú y logo -->
    <div style="flex-grow: 1;"></div>

    <!-- Contenedor del Logo y el nombre del usuario -->
    <div id="logo" style="text-align: center;">
        <a href="/portes_nuevos_recibidos.php" style="max-width: 1000px;">
            <img src="/imagenes/logos/intertrucker_chato.jpg" 
                 alt="InterTrucker Logo" 
                 style="max-height: 100px; 
                        width: auto; 
                        height: auto; 
                        max-width: 100%;">
        </a>
        <div style="background: #001c7d; padding: 3px; color: white; font-size: 20px;">
            <!-- Muestra el nombre del usuario -->
            <?php echo $_SESSION['nombre_usuario']; ?>
        </div>
    </div>

    <!-- Espaciador para alinear el buscador a la derecha -->
    <div style="flex-grow: 1;"></div>

    <!-- Botón Lupa a la derecha -->
    <form method="GET" action="buscador_general.php" style="display: inline;">
        <input type="hidden" id="filter" name="filter" value="portes">
        <input type="hidden" name="q" id="search-header-input">
        <button type="button" 
                onclick="openSearch()" 
                style="background: none; 
                       border: none; 
                       cursor: pointer; 
                       font-size: 2rem; 
                       color: white;">
            🔍
        </button>
    </form>
</header>

<script>
    function toggleDropdown(id) {
        const dropdown = document.getElementById(id);
        // Si ya está visible, lo oculta; si está oculto, lo muestra
        dropdown.style.display = (dropdown.style.display === 'block') ? 'none' : 'block';
    }

    function openSearch() {
        const searchTerm = prompt("Introduce Mercancía, Origen o Destino:");
        if (searchTerm) {
            document.getElementById('search-header-input').value = searchTerm;
            document.querySelector('form').submit();
        }
    }
</script>

</body>
</html>
