<?php
session_start();
include 'conexion.php'; // Conexión a la base de datos

// Verificar si el usuario está en sesión
if (!isset($_SESSION['usuario_id'])) {
    echo "Error: No has iniciado sesión.";
    exit();
}

$contacto_id = $_GET['contacto_id'];
$usuario_id = $_SESSION['usuario_id'];

// Obtener los detalles del contacto
$sql_contacto = "SELECT u.nombre_usuario, u.email, u.telefono, c.observaciones 
                 FROM usuarios u
                 JOIN contactos c ON u.id = c.contacto_usuario_id
                 WHERE c.usuario_id = ? AND u.id = ?";
$stmt = $conn->prepare($sql_contacto);
$stmt->bind_param("ii", $usuario_id, $contacto_id);
$stmt->execute();
$contacto = $stmt->get_result()->fetch_assoc();

// Guardar observaciones
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['observaciones'])) {
    $observaciones = $_POST['observaciones'];

    // Actualizar observaciones en la base de datos
    $sql_actualizar_observaciones = "UPDATE contactos SET observaciones = ? WHERE usuario_id = ? AND contacto_usuario_id = ?";
    $stmt = $conn->prepare($sql_actualizar_observaciones);
    $stmt->bind_param("sii", $observaciones, $usuario_id, $contacto_id);
    $stmt->execute();

    // Redirigir para evitar reenvío del formulario
    header("Location: ver_contacto.php?contacto_id=$contacto_id&guardado=1");
    exit();
}

// Eliminar contacto
if (isset($_GET['eliminar_contacto'])) {
    $sql_eliminar = "DELETE FROM contactos WHERE usuario_id = ? AND contacto_usuario_id = ?";
    $stmt = $conn->prepare($sql_eliminar);
    $stmt->bind_param("ii", $usuario_id, $contacto_id);
    $stmt->execute();

    // Redirigir a My Network después de eliminar el contacto
    header("Location: my_network.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalles del Contacto</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

    <h1>Detalles del Contacto</h1>
    <p><strong>Nombre:</strong> <?= $contacto['nombre'] ?></p>
    <p><strong>Email:</strong> <?= $contacto['email'] ?></p>
    <p><strong>Teléfono:</strong> <?= $contacto['telefono'] ?></p>

    <!-- Mensaje de éxito tras guardar -->
    <?php if (isset($_GET['guardado']) && $_GET['guardado'] == 1): ?>
        <p style="color: green;">Observaciones guardadas con éxito.</p>
    <?php endif; ?>

    <!-- Mostrar observaciones -->
    <h2>Observaciones Guardadas:</h2>
    <p><?= nl2br($contacto['observaciones']) ?></p>

    <!-- Formulario para añadir o actualizar observaciones -->
    <form method="POST" action="ver_contacto.php?contacto_id=<?= $contacto_id ?>">
        <label for="observaciones"><strong>Escribir Observaciones:</strong></label><br>
        <textarea name="observaciones" rows="5" cols="40"><?= $contacto['observaciones'] ?></textarea><br>
        <button type="submit">Guardar Observaciones</button>
    </form>

    <!-- Opciones de Copiar y Eliminar -->
    <button onclick="copyContact()">Copiar Información</button>
    <a href="ver_contacto.php?contacto_id=<?= $contacto_id ?>&eliminar_contacto=1" 
       onclick="return confirm('¿Estás seguro de que quieres eliminar este contacto?');">Eliminar Contacto</a>
    
    <!-- Botón para volver a Todos los Contactos -->
    <br><br>
    <a href="todos_contactos.php" class="button">Cerrar</a>

    <script>
        // Función para copiar los detalles del contacto al portapapeles
        function copyContact() {
            let contactoInfo = "Nombre: <?= $contacto['nombre'] ?>\nEmail: <?= $contacto['email'] ?>\nTeléfono: <?= $contacto['telefono'] ?>";
            navigator.clipboard.writeText(contactoInfo).then(() => {
                alert("Información copiada al portapapeles.");
            });
        }
    </script>

</body>
</html>
