<?php
include '../conexion.php';

$email = $_POST['email'];
$nueva_contrasena = $_POST['nueva_contrasena'];
$confirmar_contrasena = $_POST['confirmar_contrasena'];

if ($nueva_contrasena === $confirmar_contrasena) {
    $hashed_password = password_hash($nueva_contrasena, PASSWORD_BCRYPT);

    $sql = "UPDATE usuarios SET contrasena='$hashed_password' WHERE email='$email'";

    if ($conn->query($sql) === TRUE) {
        echo "Contraseña restablecida con éxito.";
        echo "<br><a href='perfil.php'>Volver al Perfil</a>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
} else {
    echo "Las contraseñas no coinciden.";
    echo "<br><a href='reset_password.php'>Volver a intentarlo</a>";
}

$conn->close();
?>
