<?php
session_start();
include '../conexion.php';

// Verificar que el usuario esté en sesión y obtener el ID de la dirección
if (!isset($_SESSION['usuario_id']) || !isset($_GET['id'])) {
    echo "Acceso no autorizado.";
    exit();
}

$usuario_id = $_SESSION['usuario_id'];
$direccion_id = $_GET['id'];

// Comprobar que la dirección pertenece al usuario
$sql_verificar = "SELECT id FROM direcciones WHERE id = $direccion_id AND usuario_id = $usuario_id";
$resultado = $conn->query($sql_verificar);

if ($resultado->num_rows > 0) {
    // Eliminar la dirección
    $sql_eliminar = "DELETE FROM direcciones WHERE id = $direccion_id";
    if ($conn->query($sql_eliminar) === TRUE) {
        echo "Dirección eliminada correctamente.";
    } else {
        echo "Error al eliminar la dirección: " . $conn->error;
    }
} else {
    echo "Acceso no autorizado o dirección no encontrada.";
}

$conn->close();
?>
<!-- Enlace para regresar a la gestión de direcciones -->
<a href="gestionar_direcciones_usuario.php" style="display: block; margin-top: 20px;">Volver a Gestionar Direcciones</a>
