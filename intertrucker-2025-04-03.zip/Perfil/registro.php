<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>InterTrucker - Registro de Empresa</title>
    <style>
        /* ======== Cabecera y estilos principales (igual que index.php) ======== */
        header {
            background-color: #001C80; /* Color exacto del logotipo */
            padding: 20px 0;
            text-align: center;
        }
        .logo img {
            max-width: 200px;
        }

        /* Estilo para el botón de iniciar sesión (no se usa en este form, pero se mantiene por coherencia) */
        .login-button {
            display: inline-block;
            margin-top: 10px;
            padding: 15px 30px;
            font-size: 1em;
            color: #fff;
            background-color: #007bff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
        }

        /* Estilo general de la página */
        main {
            padding: 20px;
            font-family: Arial, sans-serif;
        }
        h1 {
            color: #007bff;
            text-align: center;
        }

        /* ======== Estilos específicos del formulario de registro ======== */
        form {
            max-width: 400px;
            margin: 20px; /* Centra el formulario */
        }
        label {
            display: block;
            margin-top: 1em;
            font-weight: bold;
        }
        input[type="text"],
        input[type="email"],
        input[type="password"],
        input[type="tel"] {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            box-sizing: border-box;
        }
        button[type="submit"] {
            margin-top: 1em;
            padding: 10px 20px;
            font-size: 1em;
            color: #fff;
            background-color: #007bff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button[type="button"] {
            margin-left: 5px;
        }
        #camposAdmin {
            display: none; /* Se muestra solo si elige "No" */
            margin-bottom: 1em;
        }

    </style>
</head>
<body>

    <!-- Cabecera con el logotipo (igual que en index.php) -->
    <header>
        <div class="logo">
            <img src="/imagenes/logos/logo2.png" alt="InterTrucker Logo">
        </div>
    </header>

    <!-- Contenido principal -->
    <main>
        <h1>Registro de Empresa</h1>
        <p>Este usuario adquiere el rol “administrador” y gestiona toda la empresa.</p>

        <form action="procesar_registro.php" method="POST">
            <!-- Nombre de la Empresa -->
            <label for="nombre_empresa">Nombre de la Empresa:</label>
            <input type="text" id="nombre_empresa" name="nombre_empresa" 
                   required minlength="2" maxlength="255"
                   pattern="^[A-Za-z0-9\s\.\,\-\&\(\)\']+$"
                   title="El nombre de la empresa solo puede contener letras, números, espacios y caracteres como . , - & ( ).">

            <!-- ¿Coincide con el nombre del administrador? -->
            <label style="margin-top:1em;">¿Coincide con el nombre del administrador?</label>
            <div>
                <input type="radio" id="coincide_si" name="coincide_admin" value="si" checked>
                <label for="coincide_si">Sí</label>
                <input type="radio" id="coincide_no" name="coincide_admin" value="no">
                <label for="coincide_no">No</label>
            </div>

            <!-- Campos para nombre y apellidos del administrador (solo si NO coinciden) -->
            <div id="camposAdmin">
                <label for="nombre_usuario">Nombre del Administrador:</label>
                <input type="text" id="nombre_usuario" name="nombre_usuario"
                       pattern="^[A-Za-z0-9\s\.\,\-\&\(\)\']+$"
                       title="El nombre solo puede contener letras, números y símbolos . , - & ( ).">

                <label for="apellidos">Apellidos del Administrador:</label>
                <input type="text" id="apellidos" name="apellidos"
                       pattern="^[A-Za-z0-9\s\.\,\-\&\(\)\']+$"
                       title="Los apellidos pueden contener letras, espacios y símbolos . , - & ( ).">
            </div>

            <!-- Correo Electrónico -->
            <label for="email">Correo Electrónico:</label>
            <input type="email" id="email" name="email"
                   required
                   pattern="^[\\w\\.-]+@[a-zA-Z\\d\\.-]+\\.[a-zA-Z]{2,6}$"
                   title="Introduce un correo electrónico válido.">

            <!-- Contraseña -->
            <label for="contrasena">Contraseña:</label>
            <input type="password" id="contrasena" name="contrasena"
                   required minlength="8"
                   title="La contraseña debe tener al menos 8 caracteres.">
            <button type="button" onclick="togglePasswordVisibility('contrasena')">Mostrar</button>

            <!-- Confirmación de Contraseña -->
            <label for="confirmar_contrasena">Confirmar Contraseña:</label>
            <input type="password" id="confirmar_contrasena" name="confirmar_contrasena"
                   required minlength="8"
                   title="Por favor, confirma la contraseña.">
            <button type="button" onclick="togglePasswordVisibility('confirmar_contrasena')">Mostrar</button>

            <!-- CIF -->
            <label for="cif">CIF:</label>
            <input type="text" id="cif" name="cif"
                   required minlength="9" maxlength="20"
                   pattern="^[A-Za-z0-9]+$"
                   title="El CIF solo puede contener letras y números.">

            <!-- Teléfono -->
            <label for="telefono">Teléfono de Contacto:</label>
            <input type="tel" id="telefono" name="telefono"
                   required pattern="^\\+?[0-9\\s\\-]{7,15}$"
                   title="El teléfono debe contener entre 7 y 15 dígitos, incluyendo prefijo opcional.">

            <button type="submit">Registrarse</button>
        </form>

        <p style="margin-top: 1em;">
            Una vez confirmes el email en tu correo, podrás iniciar sesión como administrador.<br>
            Iniciada la sesión podrás dar de alta a tus camiones, camioneros y gestores.<br>
            Mientras no haya gestores inscritos, no aparecerá la sección “Compañeros” en Portes Nuevos.
        </p>
    </main>

    <!-- Pie de página (igual que en index.php) -->
    <?php include '../footer.php'; ?>
    
    <!-- Scripts de funcionalidad -->
    <script>
        // Mostrar/ocultar contraseñas
        function togglePasswordVisibility(inputId) {
            const input = document.getElementById(inputId);
            const button = input.nextElementSibling;
            if (input.type === "password") {
                input.type = "text";
                button.textContent = "Ocultar";
            } else {
                input.type = "password";
                button.textContent = "Mostrar";
            }
        }

        // Mostrar/ocultar "camposAdmin" según la selección
        function actualizarVisibilidad() {
            const coincide = document.querySelector('input[name="coincide_admin"]:checked').value;
            const camposAdmin = document.getElementById("camposAdmin");
            if (coincide === "no") {
                camposAdmin.style.display = "block";
            } else {
                camposAdmin.style.display = "none";
            }
        }

        // Validación de contraseñas iguales
        document.querySelector("form").addEventListener("submit", function(event) {
            const contrasena = document.getElementById("contrasena").value;
            const confirmarContrasena = document.getElementById("confirmar_contrasena").value;
            if (contrasena !== confirmarContrasena) {
                alert("Las contraseñas no coinciden. Por favor, revísalas.");
                event.preventDefault();
            }
        });

        // Al cargar la página y cada vez que cambia la selección del radio
        document.addEventListener("DOMContentLoaded", actualizarVisibilidad);
        document.querySelectorAll('input[name="coincide_admin"]').forEach(el => {
            el.addEventListener('change', actualizarVisibilidad);
        });
    </script>
</body>
</html>
