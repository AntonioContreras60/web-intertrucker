<?php
session_start();
include_once '../conexion.php'; // Conexión a la base de datos

$email      = $_POST['email'];
$contrasena = $_POST['contrasena'];

// Verificar si el correo electrónico existe
$stmt = $conn->prepare("SELECT id, contrasena, nombre_usuario, rol, admin_id FROM usuarios WHERE email = ?");
$stmt->bind_param('s', $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();

    // Verificar contraseña con password_verify
    if (password_verify($contrasena, $row['contrasena'])) {
        
        // Configurar datos de sesión
        $_SESSION['usuario_id']    = $row['id'];
        $_SESSION['nombre_usuario']= $row['nombre_usuario'];
        $_SESSION['rol']           = $row['rol'];
        $_SESSION['admin_id']      = $row['admin_id'];

        if ($row['rol'] === 'camionero') {
            // Obtener el camionero_id asociado al usuario_id
            $stmt_camionero = $conn->prepare("SELECT id FROM camioneros WHERE usuario_id = ?");
            $stmt_camionero->bind_param('i', $row['id']);
            $stmt_camionero->execute();
            $result_camionero = $stmt_camionero->get_result();

            if ($result_camionero->num_rows > 0) {
                $camionero = $result_camionero->fetch_assoc();
                $camionero_id = $camionero['id'];

                // Obtener el tren_id activo en tren_camionero
                $stmt_tren = $conn->prepare("
                    SELECT tren_id 
                    FROM tren_camionero 
                    WHERE camionero_id = ? 
                      AND fin_tren_camionero IS NULL 
                    LIMIT 1
                ");
                $stmt_tren->bind_param('i', $camionero_id);
                $stmt_tren->execute();
                $result_tren = $stmt_tren->get_result();

                if ($result_tren->num_rows > 0) {
                    $tren = $result_tren->fetch_assoc();
                    $tren_id = $tren['tren_id'];

                    // Redirigir a tren_portes_camionero.php con el tren_id
                    header("Location: /tren_portes_camionero.php?tren_id=" . $tren_id);
                    exit();
                } else {
                    // Redirigir a una página de error: no hay un tren activo
                    header("Location: /error.php?error=no_tren_asignado");
                    exit();
                }
            } else {
                // No se encontró un perfil de camionero
                header("Location: /error.php?error=no_perfil_camionero");
                exit();
            }

        } else {
            // Administradores y Gestores van a portes_nuevos_recibidos.php
            header("Location: /portes_nuevos_recibidos.php");
            exit();
        }

    } else {
        // Contraseña incorrecta
        header("Location: /Perfil/inicio_sesion.php?error=contraseña_incorrecta");
        exit();
    }

} else {
    // Correo no registrado
    header("Location: /Perfil/inicio_sesion.php?error=email_no_registrado");
    exit();
}

// Cerrar conexiones
$stmt->close();
$conn->close();
?>
