<?php
session_start();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Usuario</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <?php
    include 'conexion.php';
    include 'header.php'; // Incluir el encabezado con el menú

    // Obtener los datos del formulario de registro
    $nombre_usuario = $_POST['nombre'];
    $email = $_POST['email'];
    $contrasena = password_hash($_POST['contrasena'], PASSWORD_BCRYPT);
    $telefono = $_POST['telefono'];
    $direccion = $_POST['direccion'];
    $tipo_usuario = $_POST['tipo_usuario'];

    // Verificar si el correo electrónico ya está registrado
    $sql_verificar = "SELECT * FROM usuarios WHERE email='$email'";
    $result = $conn->query($sql_verificar);

    if ($result->num_rows > 0) {
        // Si el correo ya está registrado
        echo "Error: El correo electrónico ya está registrado.";
        echo "<br><a href='registrar_usuario.php'>Volver al registro</a>";
    } else {
        // Insertar el nuevo usuario en la base de datos
        $sql = "INSERT INTO usuarios (nombre_usuario, email, contrasena, telefono, direccion, tipo_usuario) 
                VALUES ('$nombre_usuario', '$email', '$contrasena', '$telefono', '$direccion', '$tipo_usuario')";

        if ($conn->query($sql) === TRUE) {
            // Iniciar sesión para el usuario recién registrado
            session_start();
            $_SESSION['usuario_id'] = $conn->insert_id;
            $_SESSION['nombre_usuario'] = $nombre_usuario;

            // Mostrar mensaje de éxito con un botón para continuar al perfil
            echo "<h1>Registro hecho con éxito</h1>";
            echo "<p>Bienvenido, $nombre_usuario. Tu registro se ha completado exitosamente.</p>";
            echo "<a href='perfil_usuario.php' class='button'>Continuar a mi perfil</a>";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }

    $conn->close();

    include 'footer.php'; // Incluir el pie de página
    ?>
</body>
</html>
