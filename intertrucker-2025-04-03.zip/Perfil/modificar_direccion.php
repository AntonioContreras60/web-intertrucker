<?php
session_start();
include '../conexion.php';

// Verificar que el usuario esté en sesión y obtener el ID de la dirección
if (!isset($_SESSION['usuario_id']) || !isset($_GET['id'])) {
    echo "Acceso no autorizado.";
    exit();
}

$usuario_id = $_SESSION['usuario_id'];
$direccion_id = $_GET['id'];

// Comprobar que la dirección pertenece al usuario y obtener los datos actuales
$sql = "SELECT * FROM direcciones WHERE id = $direccion_id AND usuario_id = $usuario_id";
$resultado = $conn->query($sql);

if ($resultado->num_rows === 0) {
    echo "Dirección no encontrada o acceso no autorizado.";
    exit();
}

$direccion = $resultado->fetch_assoc();

// Procesar el formulario si se envía una actualización
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre_via = $_POST['nombre_via'];
    $numero = $_POST['numero'];
    $complemento = $_POST['complemento'];
    $ciudad = $_POST['ciudad'];
    $estado_provincia = $_POST['estado_provincia'];
    $codigo_postal = $_POST['codigo_postal'];
    $pais = $_POST['pais'];
    $tipo_direccion = $_POST['tipo_direccion'];

    $sql_actualizar = "UPDATE direcciones SET nombre_via='$nombre_via', numero='$numero', complemento='$complemento', ciudad='$ciudad', estado_provincia='$estado_provincia', codigo_postal='$codigo_postal', pais='$pais', tipo_direccion='$tipo_direccion' WHERE id = $direccion_id AND usuario_id = $usuario_id";

    if ($conn->query($sql_actualizar) === TRUE) {
        echo "Dirección actualizada correctamente.";
    } else {
        echo "Error al actualizar la dirección: " . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modificar Dirección</title>
</head>
<body>
    <h1>Modificar Dirección</h1>
    <form method="POST" action="">
        <label for="nombre_via">Calle:</label><br>
        <input type="text" id="nombre_via" name="nombre_via" value="<?= $direccion['nombre_via'] ?>" required><br>

        <label for="numero">Número:</label><br>
        <input type="text" id="numero" name="numero" value="<?= $direccion['numero'] ?>" required><br>

        <label for="complemento">Complemento:</label><br>
        <input type="text" id="complemento" name="complemento" value="<?= $direccion['complemento'] ?>"><br>

        <label for="ciudad">Ciudad:</label><br>
        <input type="text" id="ciudad" name="ciudad" value="<?= $direccion['ciudad'] ?>" required><br>

        <label for="estado_provincia">Estado/Provincia:</label><br>
        <input type="text" id="estado_provincia" name="estado_provincia" value="<?= $direccion['estado_provincia'] ?>" required><br>

        <label for="codigo_postal">Código Postal:</label><br>
        <input type="text" id="codigo_postal" name="codigo_postal" value="<?= $direccion['codigo_postal'] ?>" required><br>

        <label for="pais">País:</label><br>
        <input type="text" id="pais" name="pais" value="<?= $direccion['pais'] ?>" required><br>

        <label for="tipo_direccion">Tipo de Dirección:</label><br>
        <select id="tipo_direccion" name="tipo_direccion" required>
            <option value="fiscal" <?= $direccion['tipo_direccion'] == 'fiscal' ? 'selected' : '' ?>>Fiscal</option>
            <option value="recogida_entrega" <?= $direccion['tipo_direccion'] == 'recogida_entrega' ? 'selected' : '' ?>>Recogida/Entrega</option>
        </select><br><br>

        <button type="submit">Guardar Cambios</button>
    </form>

    <a href="gestionar_direcciones_usuario.php" style="display: block; margin-top: 20px;">Volver a Gestionar Direcciones</a>
</body>
</html>
