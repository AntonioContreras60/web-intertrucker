<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start(); // Iniciar la sesión solo si no está iniciada
}

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['usuario_id'])) {
    echo "No se encontró la sesión de usuario. Por favor, inicia sesión.";
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>InterTrucker - Inter</title>
    <link rel="stylesheet" href="../styles.css">

</head>
<body>
<?php
// Incluir el header para mostrar el menú de navegación
include '../header.php';

// Incluir archivo de conexión a la base de datos
include '../conexion.php';

// Proteger contra inyección SQL
$usuario_id = $conn->real_escape_string($_SESSION['usuario_id']);

// Obtener información del usuario
$sql = "SELECT nombre_usuario, email, telefono, cif FROM usuarios WHERE id = $usuario_id";
$result = $conn->query($sql);

// Verificar si la consulta fue exitosa
if ($result === false) {
    die("Error en la consulta SQL: " . $conn->error);
}

// Verificar si se encontraron resultados
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo "<h1>Mi Perfil</h1>";
    echo "Nombre: " . $row['nombre_usuario'] . "<br>";
    echo "Email: " . $row['email'] . "<br>";
    echo "Teléfono: " . $row['telefono'] . "<br>";
    echo "CIF: " . $row['cif'] . "<br>";
} else {
    echo "No se encontró la información del usuario en la base de datos.";
}

$conn->close(); // Cerrar la conexión a la base de datos
?>

<!-- Enlace para modificar el perfil -->
<a href="editar_perfil.php">Modificar Perfil</a><br>

<!-- Enlace para gestionar direcciones en una nueva ventana -->
<a href="gestionar_direcciones_usuario.php" target="_blank">Gestionar Direcciones</a><br>

<!-- Funcionalidades adicionales: Enlaces a cambiar contraseña, historial de portes y facturas -->
<a href="cambiar_contrasena.php">Cambiar Contraseña</a><br>
<a href="historial_portes.php">Historial de Portes</a><br>
<a href="historial_facturas.php">Historial de Facturas</a><br>

<!-- Botón de Cerrar Sesión -->
<a href="logout.php" style="display: inline-block; width: max-content; margin-top: 10px; padding: 10px 20px; background-color: #dc3545; color: white; text-decoration: none; border-radius: 5px; font-weight: bold;">Cerrar Sesión</a>

<?php include 'footer.php'; ?>
</body>
</html>