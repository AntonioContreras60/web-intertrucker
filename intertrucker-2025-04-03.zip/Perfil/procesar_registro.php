<?php
include '../conexion.php';
session_start();

// Habilitar la visualización de errores
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Recibir y sanitizar datos
    // "nombre_empresa" (obligatorio), "coincide_admin" (si/no),
    // "nombre_usuario" y "apellidos" (solo se usan si coincide_admin=no)
    $nombre_empresa = trim($_POST['nombre_empresa']);
    $coincide_admin = isset($_POST['coincide_admin']) ? $_POST['coincide_admin'] : 'si';

    // Si elige "sí", el nombre de usuario es el mismo que la empresa, apellidos vacío
    if ($coincide_admin === 'si') {
        $nombre_usuario = $nombre_empresa;
        $apellidos      = '';
    } else {
        // Toma los campos que se mostraron
        $nombre_usuario = isset($_POST['nombre_usuario']) ? trim($_POST['nombre_usuario']) : '';
        $apellidos      = isset($_POST['apellidos']) ? trim($_POST['apellidos']) : '';
    }

    $email       = trim($_POST['email']);
    $contrasena  = $_POST['contrasena'];
    $confContrasena = $_POST['confirmar_contrasena'];
    $cif         = trim($_POST['cif']);
    $telefono    = trim($_POST['telefono']);

    // Validaciones en el servidor
    $errores = [];

    // Validar nombre_empresa
    if (empty($nombre_empresa) || !preg_match("/^[\p{L}\p{N}\s\.\,\-\&\(\)\']+$/u", $nombre_empresa)) {
        $errores[] = "Nombre de empresa no válido. Solo se permiten letras, números, espacios y caracteres comunes como . , - & ( ).";
    }

    // Validar nombre_usuario y apellidos si no coincide
    if ($coincide_admin === 'no') {
        if (!empty($nombre_usuario) && !preg_match("/^[\p{L}\p{N}\s\.\,\-\&\(\)\']+$/u", $nombre_usuario)) {
            $errores[] = "Nombre de administrador no válido.";
        }
        if (!empty($apellidos) && !preg_match("/^[\p{L}\p{N}\s\.\,\-\&\(\)\']+$/u", $apellidos)) {
            $errores[] = "Apellidos no válidos.";
        }
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errores[] = "Correo electrónico no válido.";
    }
    if (strlen($contrasena) < 8 || $contrasena !== $confContrasena) {
        $errores[] = "Las contraseñas no coinciden o son demasiado cortas.";
    }
    if (empty($cif) || !preg_match("/^[A-Za-z0-9]+$/", $cif)) {
        $errores[] = "CIF no válido.";
    }
    if (empty($telefono) || !preg_match("/^\+?[0-9\s\-]{7,15}$/", $telefono)) {
        $errores[] = "Teléfono no válido.";
    }

    // Mostrar errores y detener si hay
    if (!empty($errores)) {
        foreach ($errores as $error) {
            echo "<p style='color: red;'>$error</p>";
        }
        exit;
    }

    // Generar token de verificación
    $token_verificacion = bin2hex(random_bytes(32));
    echo "<p>Token generado (depuración): $token_verificacion</p>"; // Quitar en producción
    $contrasena_hash = password_hash($contrasena, PASSWORD_DEFAULT);

    // Insertar usuario (rol=administrador)
    // Se guardan: nombre_empresa, nombre_usuario, apellidos
    $sql = $conn->prepare("
        INSERT INTO usuarios
          (nombre_empresa, nombre_usuario, apellidos, email, contrasena, cif, telefono, rol, token_verificacion, email_verificado)
        VALUES
          (?, ?, ?, ?, ?, ?, ?, 'administrador', ?, 0)
    ");
    if ($sql === false) {
        echo "<p>Error en la preparación de la consulta: " . $conn->error . "</p>";
        exit;
    }

    $sql->bind_param("sssssssss",
        $nombre_empresa,
        $nombre_usuario,
        $apellidos,
        $email,
        $contrasena_hash,
        $cif,
        $telefono,
        $token_verificacion
    );

    // Ejecutar y verificar la inserción
    if ($sql->execute()) {
        echo "<p>Usuario registrado con éxito en la base de datos.</p>";

        // Enviar el correo de verificación
        $verification_link = "https://intertrucker.net/verificar_email.php?token=$token_verificacion";
        $subject = "Verifica tu cuenta en InterTrucker";
        $message = "Hola $nombre_usuario,\n\nPor favor, haz clic en el siguiente enlace para verificar tu cuenta en InterTrucker.net:\n$verification_link\n\nGracias.";
        $headers = "From: info@intertrucker.net\r\n";

        if (mail($email, $subject, $message, $headers)) {
            echo "<p>Registro exitoso. Por favor, revisa tu correo para verificar tu cuenta antes de iniciar sesión.</p>";
            echo "<a href='inicio_sesion.php'><button>Iniciar sesión en InterTrukcer.net</button></a>";
        } else {
            echo "<p style='color: red;'>Error al enviar el correo de verificación.</p>";
        }
    } else {
        echo "<p style='color: red;'>Error al registrar el usuario: " . $conn->error . "</p>";
    }

    // Cerrar
    $sql->close();
    $conn->close();
}
?>
