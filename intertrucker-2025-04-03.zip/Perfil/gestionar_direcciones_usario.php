<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start(); // Iniciar la sesión solo si no está iniciada
}

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['usuario_id'])) {
    echo "No se encontró la sesión de usuario. Por favor, inicia sesión.";
    exit();
}

// Incluir archivo de conexión a la base de datos
include '../conexion.php';

// Proteger contra inyección SQL
$usuario_id = $conn->real_escape_string($_SESSION['usuario_id']);

// Obtener todas las direcciones del usuario
$sql_direcciones = "SELECT id, nombre_via, numero, complemento, ciudad, estado_provincia, codigo_postal, pais, tipo_direccion FROM direcciones WHERE usuario_id = $usuario_id";
$result_direcciones = $conn->query($sql_direcciones);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestionar Direcciones</title>
</head>
<body>
    <h1>Mis Direcciones</h1>

    <?php if ($result_direcciones->num_rows > 0): ?>
        <ul>
            <?php while ($direccion = $result_direcciones->fetch_assoc()): ?>
                <li>
                    Calle: <?= $direccion['nombre_via'] . ", " . $direccion['numero'] ?><br>
                    <?= !empty($direccion['complemento']) ? "Complemento: " . $direccion['complemento'] . "<br>" : '' ?>
                    Ciudad: <?= $direccion['ciudad'] ?><br>
                    Estado/Provincia: <?= $direccion['estado_provincia'] ?><br>
                    Código Postal: <?= $direccion['codigo_postal'] ?><br>
                    País: <?= $direccion['pais'] ?><br>
                    Tipo de Dirección: <?= ($direccion['tipo_direccion'] === 'fiscal') ? 'Fiscal' : 'Recogida/Entrega' ?><br>
                    <a href="modificar_direccion.php?id=<?= $direccion['id'] ?>">Modificar</a> |
                    <a href="eliminar_direccion.php?id=<?= $direccion['id'] ?>" onclick="return confirm('¿Seguro que quieres eliminar esta dirección?');">Eliminar</a>
                </li>
                <hr>
            <?php endwhile; ?>
        </ul>
    <?php else: ?>
        <p>No tienes direcciones registradas.</p>
    <?php endif; ?>

    <!-- Enlace para añadir una nueva dirección -->
    <a href="añadir_direccion_usuario.php?usuario_id=<?= $_SESSION['usuario_id'] ?>">Añadir Nueva Dirección</a><br><br>

    <!-- Botón para volver al perfil del usuario -->
    <button onclick="window.location.href='perfil_usuario.php'" style="padding: 10px 20px; background-color: #007bff; color: white; border: none; border-radius: 5px; cursor: pointer; font-weight: bold;">
        Volver al Perfil
    </button>

</body>
</html>

