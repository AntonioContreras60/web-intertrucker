<?php
include 'conexion.php';

session_start();
$usuario_id = $_SESSION['usuario_id'];

// Obtener las contraseñas del formulario
$contrasena_actual = $_POST['contrasena_actual'];
$nueva_contrasena = $_POST['nueva_contrasena'];
$confirmar_contrasena = $_POST['confirmar_contrasena'];

// Verificar la contraseña actual
$sql = "SELECT contrasena FROM usuarios WHERE id=$usuario_id";
$result = $conn->query($sql);
$row = $result->fetch_assoc();

if (password_verify($contrasena_actual, $row['contrasena'])) {
    if ($nueva_contrasena === $confirmar_contrasena) {
        $nueva_contrasena_hash = password_hash($nueva_contrasena, PASSWORD_BCRYPT);
        $sql = "UPDATE usuarios SET contrasena='$nueva_contrasena_hash' WHERE id=$usuario_id";
        if ($conn->query($sql) === TRUE) {
            echo "Contraseña cambiada con éxito.";
            echo "<br><a href='perfil_usuario.php'>Volver a mi perfil</a>";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "Las nuevas contraseñas no coinciden.";
    }
} else {
    echo "La contraseña actual es incorrecta.";
}

$conn->close();
?>
