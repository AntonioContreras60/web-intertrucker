<?php
include '../conexion.php'; // Ajusta la ruta si es necesario

// Recibir los datos del formulario de registro
$nombre_usuario = $_POST['nombre_usuario'];
$email = $_POST['email'];
$contrasena = password_hash($_POST['contrasena'], PASSWORD_DEFAULT); // Encriptar la contraseña
$tipo_usuario = $_POST['tipo_usuario'];
$telefono = $_POST['telefono'];
$cif = $_POST['cif'];

// Insertar el nuevo usuario en la base de datos
$sql_usuario = "INSERT INTO usuarios (nombre_usuario, email, contrasena, tipo_usuario, telefono, cif)
                VALUES ('$nombre_usuario', '$email', '$contrasena', '$tipo_usuario', '$telefono', '$cif')";

if ($conn->query($sql_usuario) === TRUE) {
    $usuario_id = $conn->insert_id; // Obtener el ID del nuevo usuario registrado

    // Redirigir a añadir_direccion_usuario.php con el usuario_id en la URL
    header("Location: añadir_direccion_usuario.php?usuario_id=" . $usuario_id);
    exit();
} else {
    echo "Error al registrar el usuario: " . $conn->error;
}

// Cerrar la conexión
$conn->close();
?>
