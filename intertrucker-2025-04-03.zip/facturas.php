<?php
session_start();
include 'conexion.php'; // Ajusta la ruta si es distinto

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Verificar sesión
if (!isset($_SESSION['usuario_id']) || !isset($_SESSION['rol']) || !isset($_SESSION['admin_id'])) {
    header('Location: /Perfil/inicio_sesion.php');
    exit();
}

$usuario_id = $_SESSION['usuario_id'];
$rol        = $_SESSION['rol'];
$admin_id   = $_SESSION['admin_id'];

// Inicializar arreglo de miembros (usuarios + camioneros)
$miembros = [];

// 1. Usuarios asociados a admin_id
$sql_usuarios = "
    SELECT id, nombre_usuario AS nombre, apellidos, rol
    FROM usuarios
    WHERE admin_id = ?
";
$stmt_usuarios = $conn->prepare($sql_usuarios);
$stmt_usuarios->bind_param('i', $admin_id);
$stmt_usuarios->execute();
$result_usuarios = $stmt_usuarios->get_result();
while ($row = $result_usuarios->fetch_assoc()) {
    $miembros[] = [
        'id'     => $row['id'],
        'nombre' => $row['nombre'] . ' ' . $row['apellidos'],
        'rol'    => $row['rol']
    ];
}
$stmt_usuarios->close();

// 2. Camioneros (si manejas tabla aparte)
$sql_camioneros = "
    SELECT c.id, u.nombre_usuario AS nombre, u.apellidos, 'camionero' AS rol
    FROM camioneros c
    JOIN usuarios u ON c.usuario_id = u.id
    WHERE u.admin_id = ?
      AND c.activo = 1
";
$stmt_camioneros = $conn->prepare($sql_camioneros);
$stmt_camioneros->bind_param('i', $admin_id);
$stmt_camioneros->execute();
$result_camioneros = $stmt_camioneros->get_result();
while ($row = $result_camioneros->fetch_assoc()) {
    $miembros[] = [
        'id'     => $row['id'],
        'nombre' => $row['nombre'] . ' ' . $row['apellidos'],
        'rol'    => $row['rol']
    ];
}
$stmt_camioneros->close();

// Filtros dinámicos
$condiciones       = [];
$parametros        = [];
$tipos_parametros  = "";

// Filtro por fecha_inicio
if (!empty($_GET['fecha_inicio'])) {
    $condiciones[]    = "f.fecha >= ?";
    $parametros[]     = $_GET['fecha_inicio'];
    $tipos_parametros .= "s";
}
// Filtro por fecha_fin
if (!empty($_GET['fecha_fin'])) {
    $condiciones[]    = "f.fecha <= ?";
    $parametros[]     = $_GET['fecha_fin'];
    $tipos_parametros .= "s";
}
// Filtro por tipo de factura (gastos, ingresos, etc.)
if (!empty($_GET['tipo'])) {
    $condiciones[]    = "f.tipo = ?";
    $parametros[]     = $_GET['tipo'];
    $tipos_parametros .= "s";
}
// Filtro por miembro (usuario) que la ha hecho
// NOTA: ya no usamos f.camionero_id, pues no existe
if (!empty($_GET['miembro'])) {
    $condiciones[]    = "f.usuario_id = ?";
    $parametros[]     = $_GET['miembro'];
    $tipos_parametros .= "i";
}

// Construir la consulta base según el rol
if ($rol == 'administrador' || $rol == 'gestor') {
    // Para admin/gestor, se listan TODAS las facturas de esa empresa:
    $sql_facturas = "
        SELECT f.id, f.fecha, f.tipo, f.cantidad, f.foto, f.observaciones, f.tren_id,
               IFNULL(CONCAT(u.nombre_usuario, ' ', u.apellidos), 'Desconocido') AS hecho_por,
               t.tren_nombre
        FROM facturas f
        LEFT JOIN usuarios u ON f.usuario_id = u.id
        LEFT JOIN tren t ON f.tren_id = t.id   -- Aquí unimos la tabla 'tren' por tren_id
        WHERE u.admin_id = ?
    ";
    // El primer parámetro es admin_id
    $parametros       = array_merge([$admin_id], $parametros);
    $tipos_parametros = "i" . $tipos_parametros;

} elseif ($rol == 'camionero') {
    // Para rol camionero, solo se listan sus facturas
    $sql_facturas = "
        SELECT f.id, f.fecha, f.tipo, f.cantidad, f.foto, f.observaciones, f.tren_id,
               t.tren_nombre
        FROM facturas f
        LEFT JOIN tren t ON f.tren_id = t.id
        WHERE f.usuario_id = ?
    ";
    $parametros       = array_merge([$usuario_id], $parametros);
    $tipos_parametros = "i" . $tipos_parametros;
}

// Agregar condiciones dinámicas
if (!empty($condiciones)) {
    $sql_facturas .= " AND " . implode(" AND ", $condiciones);
}
$sql_facturas .= " ORDER BY f.fecha DESC";

// Preparar la consulta
$stmt_facturas = $conn->prepare($sql_facturas);
if (!$stmt_facturas) {
    die("Error en la preparación de la consulta: " . $conn->error);
}
$stmt_facturas->bind_param($tipos_parametros, ...$parametros);
$stmt_facturas->execute();
$result_facturas = $stmt_facturas->get_result();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Listado de Facturas - InterTrucker</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <?php include 'header.php'; ?>

    <main>
        <h1>Facturas</h1>
        <a href="registro_nueva_factura.php" class="button">Registrar Nueva Factura</a>
        <h2>Listado de Facturas</h2>

        <!-- Formulario de Filtros (opcional) -->
        <form method="get" action="facturas.php" class="filtros">
            <label for="fecha_inicio">Fecha desde:</label>
            <input type="date" name="fecha_inicio" id="fecha_inicio" value="<?php echo htmlspecialchars($_GET['fecha_inicio'] ?? ''); ?>">

            <label for="fecha_fin">Fecha hasta:</label>
            <input type="date" name="fecha_fin" id="fecha_fin" value="<?php echo htmlspecialchars($_GET['fecha_fin'] ?? ''); ?>">

            <label for="tipo">Tipo de Factura:</label>
            <select name="tipo" id="tipo">
                <option value="">--Todos--</option>
                <option value="ingreso" <?php if(($_GET['tipo'] ?? '') === 'ingreso') echo 'selected'; ?>>Ingreso</option>
                <option value="gasto" <?php if(($_GET['tipo'] ?? '') === 'gasto') echo 'selected'; ?>>Gasto</option>
                <!-- Ajusta más tipos si los manejas -->
            </select>

            <label for="miembro">Hecho por:</label>
            <select name="miembro" id="miembro">
                <option value="">--Todos--</option>
                <?php 
                // Listar todos los usuarios/camioneros de la empresa:
                foreach ($miembros as $m) {
                    $selected = (($_GET['miembro'] ?? '') == $m['id']) ? 'selected' : '';
                    echo "<option value='".$m['id']."' $selected>".$m['nombre']."</option>";
                }
                ?>
            </select>

            <button type="submit" class="button">Filtrar</button>
        </form>

        <table>
            <thead>
                <tr>
                    <th>Fecha</th>
                    <th>Tipo</th>
                    <th>Cantidad</th>
                    <?php if ($rol != 'camionero'): ?>
                        <th>Hecho por</th>
                    <?php endif; ?>
                    <th>Tren</th> <!-- Nueva columna para mostrar el tren asociado -->
                    <th>Foto</th>
                    <th>Observaciones</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
            <?php if ($result_facturas->num_rows > 0): ?>
                <?php while ($row = $result_facturas->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['fecha']); ?></td>
                        <td><?php echo htmlspecialchars($row['tipo']); ?></td>
                        <td><?php echo number_format($row['cantidad'], 2); ?> €</td>
                        <?php if ($rol != 'camionero'): ?>
                            <td><?php echo htmlspecialchars($row['hecho_por']); ?></td>
                        <?php endif; ?>
                        <td>
                            <!-- Mostramos el nombre del tren si existe, sino decimos "Sin tren" -->
                            <?php 
                            echo $row['tren_nombre'] 
                                ? htmlspecialchars($row['tren_nombre']) 
                                : "Sin tren"; 
                            ?>
                        </td>
                        <td>
                            <?php 
                            echo $row['foto'] 
                                ? "<a href='{$row['foto']}' target='_blank'>Ver Foto</a>" 
                                : 'Sin Foto'; 
                            ?>
                        </td>
                        <td>
                            <?php echo htmlspecialchars($row['observaciones'] ?? ''); ?>
                        </td>
                        <td>
                            <a href="detalle_factura.php?id=<?php echo $row['id']; ?>">Ver Detalles</a>
                            <!-- Aquí puedes añadir más acciones, editar, eliminar, etc. -->
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="8">No se encontraron facturas.</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </main>

    <?php include 'footer.php'; ?>
</body>
</html>
