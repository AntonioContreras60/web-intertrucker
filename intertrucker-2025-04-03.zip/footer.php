<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Footer</title>
    <style>
        /* Mismo color que el header (por ejemplo, #001C80) */
        footer {
    width: 100%;
    background-color: #001C80;
    color: #fff;
    padding: 20px;
    text-align: center;
    margin: 0;
}

    </style>
</head>
<body>

<footer>
    <p>© 2024 InterTrucker. Todos los derechos reservados.</p>
</footer>

</body>
