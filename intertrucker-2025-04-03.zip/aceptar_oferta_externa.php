<?php
session_start();
include 'conexion.php'; // Conexión a la base de datos

// Verificar si el usuario está autenticado
if (!isset($_SESSION['usuario_id'])) {
    echo "Error: Usuario no autenticado.";
    exit;
}

$usuario_id = $_SESSION['usuario_id']; // ID del usuario autenticado

// Verificar los datos recibidos
if (!isset($_POST['oferta_id'], $_POST['porte_id'], $_POST['accion']) || $_POST['accion'] !== 'aceptar') {
    echo "<p>Error: No se recibieron los datos necesarios.</p>";
    echo "<a href='portes_nuevos_propios.php'><button>Volver</button></a>";
    exit;
}

$oferta_id = intval($_POST['oferta_id']);
$porte_id = intval($_POST['porte_id']);

// Actualizar la oferta aceptada
try {
    // Iniciar transacción
    $conn->begin_transaction();

    // Cambiar el estado de la oferta seleccionada a 'asignado'
    $sql_aceptar = "UPDATE ofertas_varios SET estado_oferta = 'asignado' WHERE id = ? AND porte_id = ?";
    $stmt_aceptar = $conn->prepare($sql_aceptar);
    $stmt_aceptar->bind_param("ii", $oferta_id, $porte_id);
    $stmt_aceptar->execute();

    if ($stmt_aceptar->affected_rows > 0) {
        // Cambiar el estado de las otras ofertas a 'asignado_a_otro'
        $sql_rechazar_otras = "UPDATE ofertas_varios SET estado_oferta = 'asignado_a_otro' WHERE porte_id = ? AND id != ?";
        $stmt_rechazar_otras = $conn->prepare($sql_rechazar_otras);
        $stmt_rechazar_otras->bind_param("ii", $porte_id, $oferta_id);
        $stmt_rechazar_otras->execute();

        // Confirmar transacción
        $conn->commit();

        // Mostrar mensaje de éxito
        echo "<p>La oferta fue aceptada exitosamente.</p>";
    } else {
        throw new Exception("No se pudo aceptar la oferta.");
    }

    $stmt_aceptar->close();
    $stmt_rechazar_otras->close();
} catch (Exception $e) {
    // Revertir transacción en caso de error
    $conn->rollback();
    echo "<p>Error: " . $e->getMessage() . "</p>";
}

// Cerrar la conexión
$conn->close();
?>

<!-- Botón para volver -->
<a href="portes_nuevos_propios.php"><button>Volver</button></a>

<link rel="stylesheet" href="styles.css">
