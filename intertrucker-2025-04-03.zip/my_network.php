<?php
session_start(); // Asegurarse de que la sesión esté iniciada

include 'conexion.php'; // Conexión a la base de datos
include 'header.php'; // Incluir el archivo de encabezado

// Asegurarse de que el usuario esté en sesión
$usuario_id = $_SESSION['usuario_id'];

// Si el usuario es un gestor, obtener el admin_id para centralizar los contactos
$sql_admin_id = "SELECT admin_id FROM usuarios WHERE id = ?";
$stmt_admin_id = $conn->prepare($sql_admin_id);
$stmt_admin_id->bind_param("i", $usuario_id);
$stmt_admin_id->execute();
$result_admin_id = $stmt_admin_id->get_result();
if ($result_admin_id->num_rows > 0) {
    $admin_id = $result_admin_id->fetch_assoc()['admin_id'];
} else {
    $admin_id = $usuario_id;
}
 // ID del usuario en sesión

// Consulta para obtener los grupos del usuario
$sql_grupos = "SELECT * FROM grupos WHERE usuario_id = ?";
$stmt_grupos = $conn->prepare($sql_grupos);
$stmt_grupos->bind_param("i", $admin_id);
$stmt_grupos->execute();
$resultado_grupos = $stmt_grupos->get_result();

// Buscar contacto y verificar si ya es un contacto
if (isset($_POST['busqueda_contacto'])) {
    $busqueda = '%' . $_POST['busqueda_contacto'] . '%';

    // Preparar consulta para buscar solo administradores
    $sql = "SELECT 
                u.id, 
                u.nombre_usuario, 
                u.email, 
                CASE WHEN c.contacto_usuario_id IS NOT NULL THEN 'Sí' ELSE 'No' END AS es_contacto
            FROM usuarios u
            LEFT JOIN contactos c ON (u.id = c.contacto_usuario_id AND c.usuario_id = ?)
            WHERE (u.nombre_usuario LIKE ? OR u.email LIKE ?) AND u.rol = 'administrador'";
    
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error al preparar la consulta: " . $conn->error);
    }

    $stmt->bind_param("iss", $admin_id, $busqueda, $busqueda);
    
    if (!$stmt->execute()) {
        die("Error al ejecutar la consulta: " . $stmt->error);
    }

    $resultado_busqueda = $stmt->get_result();
}

// Eliminar contacto si es necesario
if (isset($_GET['eliminar_contacto'])) {
    $contacto_usuario_id = $_GET['eliminar_contacto'];

    // Verificar si el contacto existe en la lista del usuario
    $sql_verificar = "SELECT * FROM contactos WHERE usuario_id = ? AND contacto_usuario_id = ?";
    $stmt_verificar = $conn->prepare($sql_verificar);
    $stmt_verificar->bind_param("ii", $admin_id, $contacto_usuario_id);
    $stmt_verificar->execute();
    $verificar_resultado = $stmt_verificar->get_result();

    if ($verificar_resultado->num_rows > 0) {
        // Eliminar el contacto
        $sql_eliminar = "DELETE FROM contactos WHERE usuario_id = ? AND contacto_usuario_id = ?";
        $stmt_eliminar = $conn->prepare($sql_eliminar);
        $stmt_eliminar->bind_param("ii", $admin_id, $contacto_usuario_id);
        $stmt_eliminar->execute();

        echo "<p>Contacto eliminado correctamente.</p>";
    } else {
        echo "<p>Este contacto no existe en tu lista.</p>";
    }
}

// Añadir contacto si es necesario
if (isset($_GET['añadir_contacto'])) {
    $contacto_usuario_id = $_GET['añadir_contacto'];

    // Verificar si el contacto ya existe en la lista de contactos del usuario
    $sql_verificar = "SELECT * FROM contactos WHERE usuario_id = ? AND contacto_usuario_id = ?";
    $stmt_verificar = $conn->prepare($sql_verificar);
    $stmt_verificar->bind_param("ii", $admin_id, $contacto_usuario_id);
    $stmt_verificar->execute();
    $verificar_resultado = $stmt_verificar->get_result();

    if ($verificar_resultado->num_rows == 0) {
        // Añadir el contacto
        $sql_insertar = "INSERT INTO contactos (usuario_id, contacto_usuario_id) VALUES (?, ?)";
        $stmt_insertar = $conn->prepare($sql_insertar);
        $stmt_insertar->bind_param("ii", $admin_id, $contacto_usuario_id);

        if ($stmt_insertar->execute()) {
            echo "<div style='font-size: 3em; color: green; text-align: center;'>Contacto añadido correctamente.</div>";
        } else {
            echo "<div style='font-size: 3em; color: red; text-align: center;'>Error al añadir el contacto.</div>";
        }
    } else {
        echo "<div style='font-size: 3em; color: orange; text-align: center;'>Este contacto ya está en tu lista.</div>";
    }

    echo "<div style='text-align: center; margin-top: 40px;'>
            <button onclick=\"window.location.href='my_network.php'\" style='padding: 20px 40px; font-size: 2em;'>Volver a My Network</button>
          </div>";

    exit();
}

// Guardar nueva entidad
if (isset($_POST['crear_entidad'])) {
    $nombre = $conn->real_escape_string($_POST['nombre']);
    $telefono = $conn->real_escape_string($_POST['telefono']);
    $email = $conn->real_escape_string($_POST['email']);
    $cif = $conn->real_escape_string($_POST['cif']);
    $observaciones = $conn->real_escape_string($_POST['observaciones']);

    $sql_insert_entidad = "INSERT INTO entidades (usuario_id, nombre, telefono, email, cif, observaciones) 
                           VALUES (?, ?, ?, ?, ?, ?)";
    $stmt_insert = $conn->prepare($sql_insert_entidad);
    $stmt_insert->bind_param("isssss", $admin_id, $nombre, $telefono, $email, $cif, $observaciones);

    if ($stmt_insert->execute()) {
        $entidad_id = $stmt_insert->insert_id; // Obtener el ID de la entidad creada
        header("Location: gestionar_direcciones_entidad.php?entidad_id=$entidad_id");
        exit();
    } else {
        echo "<p>Error al crear la entidad: " . $conn->error . "</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Network</title>
    <link rel="stylesheet" href="styles.css?v=1.1">
</head>
<body>

<h1>My Network</h1>

<!-- Formulario para buscar contacto -->
<h2>Buscar Nuevo Contacto Usuario:</h2>
<form method="POST" action="my_network.php">
    <input type="text" name="busqueda_contacto" placeholder="Buscar por email o teléfono">
    <button type="submit">Buscar Nuevo Contacto</button>
</form>

<!-- Mostrar resultados de la búsqueda de contactos justo después del formulario -->
<?php if (isset($resultado_busqueda) && $resultado_busqueda->num_rows > 0): ?>
    <h3>Resultados de Búsqueda:</h3>
    <ul>
        <?php while ($contacto = $resultado_busqueda->fetch_assoc()): ?>
            <li>
                <?= htmlspecialchars($contacto['nombre_usuario']) . " (" . htmlspecialchars($contacto['email']) . ") - Ya es contacto: " . htmlspecialchars($contacto['es_contacto']) ?>
                <?php if ($contacto['es_contacto'] == 'No'): ?>
                    <a href="my_network.php?añadir_contacto=<?= htmlspecialchars($contacto['id']) ?>">Añadir Contacto</a>
                <?php endif; ?>
            </li>
        <?php endwhile; ?>
    </ul>
<?php elseif (isset($resultado_busqueda)): ?>
    <p>No se encontraron resultados.</p>
<?php endif; ?>


  <!-- Botón para mostrar/ocultar el formulario de crear entidad -->
<h2>Crear Nuevo Contacto:</h2>
<button onclick="toggleForm()">Crear Contacto</button>

<!-- Formulario de Crear Entidad, inicialmente oculto -->
<div id="crearEntidadForm" style="display:none;">
    <form method="POST" action="my_network.php">
        <label for="nombre">Nombre de la Entidad:</label>
        <input type="text" id="nombre" name="nombre" required><br>

        <label for="telefono">Teléfono:</label>
        <input type="tel" id="telefono" name="telefono" required><br>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required><br>

        <label for="cif">CIF/NIF/NIE:</label>
        <input type="text" id="cif" name="cif" required><br>

        <label for="observaciones">Observaciones:</label>
        <textarea id="observaciones" name="observaciones"></textarea><br>

        <!-- Botón para gestionar direcciones -->
        <label>Direcciones:</label>
        <button type="button" onclick="window.location.href='añadir_direccion.php?entidad_id=<?php echo $entidad_id; ?>'">
            Añadir/Editar Direcciones
        </button><br>

        <button type="submit" name="crear_entidad">Crear Entidad</button>
    </form>
</div>

<script>
    // Función para alternar la visibilidad del formulario
    function toggleForm() {
        var form = document.getElementById('crearEntidadForm');
        if (form.style.display === 'none') {
            form.style.display = 'block';
        } else {
            form.style.display = 'none';
        }
    }
</script>



    <!-- Listado de Mis Contactos -->
    <h2>Mis Contactos:</h2>

    <button style="font-weight: bold;" onclick="toggleContacts()">
        Mostrar todos los contactos y entidades
    </button>

    <div id="contactosEntidades" style="display: none;">
    <?php
    // Obtener contactos del administrador
    $sql_contactos = "SELECT c.contacto_usuario_id, u.nombre_usuario, u.email FROM contactos c JOIN usuarios u ON c.contacto_usuario_id = u.id WHERE c.usuario_id = ?";
    $stmt_contactos = $conn->prepare($sql_contactos);
    $stmt_contactos->bind_param("i", $admin_id);
    $stmt_contactos->execute();
    $resultado_contactos = $stmt_contactos->get_result();

    // Obtener entidades del administrador
    $sql_entidades = "SELECT id, nombre, email FROM entidades WHERE usuario_id = ?";
    $stmt_entidades = $conn->prepare($sql_entidades);
    $stmt_entidades->bind_param("i", $admin_id);
    $stmt_entidades->execute();
    $resultado_entidades = $stmt_entidades->get_result();
    ?>

    <?php if ($resultado_contactos->num_rows > 0): ?>
        <ul>
            <?php while ($contacto = $resultado_contactos->fetch_assoc()): ?>
                <li>
                    Contacto: <?= htmlspecialchars($contacto['nombre_usuario']) . " (" . htmlspecialchars($contacto['email']) . ")" ?>
                </li>
            <?php endwhile; ?>
        </ul>
    <?php else: ?>
        <p>No tienes contactos de usuarios aún.</p>
    <?php endif; ?>

    <?php if ($resultado_entidades->num_rows > 0): ?>
        <ul>
            <?php while ($entidad = $resultado_entidades->fetch_assoc()): ?>
                <li>
                    Entidad: <?= htmlspecialchars($entidad['nombre']) . " (" . htmlspecialchars($entidad['email']) . ")" ?>
                </li>
            <?php endwhile; ?>
        </ul>
    <?php else: ?>
        <p>No tienes entidades aún.</p>
    <?php endif; ?>
</div>

    <?php
    // Obtener contactos del administrador
    $sql_contactos = "SELECT c.contacto_usuario_id, u.nombre_usuario, u.email FROM contactos c JOIN usuarios u ON c.contacto_usuario_id = u.id WHERE c.usuario_id = ?";
    $stmt_contactos = $conn->prepare($sql_contactos);
    $stmt_contactos->bind_param("i", $admin_id);
    $stmt_contactos->execute();
    $resultado_contactos = $stmt_contactos->get_result();

    // Obtener entidades del administrador
    $sql_entidades = "SELECT id, nombre, email FROM entidades WHERE usuario_id = ?";
    $stmt_entidades = $conn->prepare($sql_entidades);
    $stmt_entidades->bind_param("i", $admin_id);
    $stmt_entidades->execute();
    $resultado_entidades = $stmt_entidades->get_result();
    ?>

    

    
        <!-- Listado de Grupos -->
    <h2>Grupos:</h2>
    <?php if ($resultado_grupos->num_rows > 0): ?>
        <ul>
            <?php while ($grupo = $resultado_grupos->fetch_assoc()): ?>
                <li>
                    <?= $grupo['nombre'] ?>
                    <a href="ver_grupo.php?grupo_id=<?= $grupo['id'] ?>" class="button">Ver</a>
                </li>
            <?php endwhile; ?>
        </ul>
    <?php else: ?>
        <p>No tienes grupos creados aún.</p>
    <?php endif; ?>

<script>
    // Función para alternar la visibilidad del listado de contactos y entidades
    function toggleContacts() {
        var div = document.getElementById('contactosEntidades');
        if (div.style.display === 'none') {
            div.style.display = 'block';
        } else {
            div.style.display = 'none';
        }
    }
</script>
</body>
</html>
