<?php
// Conexi�n a la base de datos
include 'db_connection.php';

// Obtener el ID del porte
$porte_id = $_POST['porte_id'];

// Subida de fotos de entrega
if (isset($_FILES['foto_entrega'])) {
    $target_dir = "uploads/";
    $file_name = basename($_FILES['foto_entrega']['name']);
    $target_file = $target_dir . $file_name;

    // Mover el archivo a la carpeta 'uploads'
    if (move_uploaded_file($_FILES['foto_entrega']['tmp_name'], $target_file)) {
        // Insertar la ruta del archivo en la base de datos
        $sql = "INSERT INTO archivos_entrega_recogida (porte_id, tipo, archivo_nombre) 
                VALUES ($porte_id, 'foto', '$file_name')";
        mysqli_query($conn, $sql);
        echo "Foto de la entrega subida y registrada correctamente.";
    } else {
        echo "Error al subir la foto de la entrega.";
    }
}

// Subida de videos de entrega
if (isset($_FILES['video_entrega'])) {
    $target_dir = "uploads/";
    $file_name = basename($_FILES['video_entrega']['name']);
    $target_file = $target_dir . $file_name;

    // Mover el archivo a la carpeta 'uploads'
    if (move_uploaded_file($_FILES['video_entrega']['tmp_name'], $target_file)) {
        // Insertar la ruta del archivo en la base de datos
        $sql = "INSERT INTO archivos_entrega_recogida (porte_id, tipo, archivo_nombre) 
                VALUES ($porte_id, 'video', '$file_name')";
        mysqli_query($conn, $sql);
        echo "Video de la entrega subido y registrado correctamente.";
    } else {
        echo "Error al subir el video de la entrega.";
    }
}

// Guardar observaciones de la entrega
if (isset($_POST['observaciones_entrega'])) {
    $observaciones = $_POST['observaciones_entrega'];
    $sql = "UPDATE portes SET observaciones_entrega = '$observaciones' WHERE id = $porte_id";
    mysqli_query($conn, $sql);
}

// Registrar hora de llegada o salida
if (isset($_POST['registrar_hora'])) {
    $hora_actual = date('H:i:s');

    if ($_POST['registrar_hora'] == 'llegada') {
        $sql = "UPDATE portes SET hora_llegada_entrega = '$hora_actual' WHERE id = $porte_id";
    } elseif ($_POST['registrar_hora'] == 'salida') {
        $sql = "UPDATE portes SET hora_salida_entrega = '$hora_actual' WHERE id = $porte_id";
    }

    mysqli_query($conn, $sql);
}

echo "Entrega registrada correctamente.";
?>