<?php
$password = '12345678';
$hash = password_hash($password, PASSWORD_BCRYPT);
echo "El hash bcrypt de la contraseña '$password' es: " . $hash;
?>
