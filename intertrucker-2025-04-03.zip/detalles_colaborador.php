<?php
session_start();
include 'conexion.php';

// Solo permitir acceso si el usuario es administrador
if ($_SESSION['rol'] !== 'administrador') {
    die("<p style='font-size: 3rem; font-weight: bold;'>No tiene permiso para acceder a esta sección</p>");
}

// Verificar si se proporciona un ID válido
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("ID de colaborador inválido.");
}

$colaborador_id = $_GET['id'];

// Obtener detalles del usuario
$sql = "SELECT * FROM usuarios WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $colaborador_id);
$stmt->execute();
$result = $stmt->get_result();
$colaborador = $result->fetch_assoc();

if (!$colaborador) {
    die("Colaborador no encontrado.");
}

// Verificar si el colaborador es camionero
$sql_camionero = "SELECT * FROM camioneros WHERE usuario_id = ?";
$stmt = $conn->prepare($sql_camionero);
$stmt->bind_param("i", $colaborador_id);
$stmt->execute();
$result_camionero = $stmt->get_result();
$camionero = $result_camionero->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Detalles del Gestor</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        h1, h2 { color: #333; }
        form { margin-bottom: 20px; }
        label { display: block; margin-bottom: 5px; }
        input { margin-bottom: 10px; }
        button { margin-top: 10px; }
        #camionero_fields { display: none; }
    </style>
    <script>
        function toggleCamioneroFields() {
            const checkbox = document.getElementById('convertir_camionero');
            const fields = document.getElementById('camionero_fields');
            fields.style.display = checkbox.checked ? 'block' : 'none';
        }
    </script>
</head>
<body>
    <?php include 'header.php'; ?>
    <h1>Detalles del Gestor</h1>

    <form action="actualizar_usuario.php" method="POST">
        <input type="hidden" name="usuario_id" value="<?php echo $colaborador_id; ?>">

        <!-- Información de Usuario -->
        <h2>Información de Usuario</h2>
        <label>Nombre: <input type="text" name="nombre_usuario" value="<?php echo htmlspecialchars($colaborador['nombre_usuario']); ?>" required></label>
        <label>Apellidos: <input type="text" name="apellidos" value="<?php echo htmlspecialchars($colaborador['apellidos']); ?>" required></label>
        <label>Teléfono: <input type="text" name="telefono" value="<?php echo htmlspecialchars($colaborador['telefono']); ?>"></label>
        <label>CIF: <input type="text" name="cif" value="<?php echo htmlspecialchars($colaborador['cif']); ?>" required></label>
        <label>Email: <input type="email" value="<?php echo htmlspecialchars($colaborador['email']); ?>" disabled></label>
        <label>Estado: <?php echo $colaborador['estado'] == 'activo' ? 'Activo' : 'Inactivo'; ?></label>

        <!-- Convertir en Camionero -->
        <?php if (!$camionero): ?>
            <h2>Convertir en Camionero</h2>
            <label>
                <input type="checkbox" id="convertir_camionero" name="convertir_camionero" onchange="toggleCamioneroFields()">
                Convertir en Camionero
            </label>
            <div id="camionero_fields">
                <label>Fecha de Contratación: <input type="date" name="fecha_contratacion"></label>
                <label>Tipo Carnet: <input type="text" name="tipo_carnet"></label>
                <label>Caducidad Carnet: <input type="date" name="fecha_caducidad"></label>
                <label>Número de Licencia: <input type="text" name="num_licencia"></label>
                <label>Caducidad Profesional: <input type="date" name="caducidad_profesional"></label>
            </div>
        <?php endif; ?>

        <!-- Botón único para guardar todos los cambios -->
        <button type="submit">Guardar Cambios</button>
    </form>

    <!-- Botón para cambiar el estado activo/inactivo -->
    <form action="cambiar_estado_colaborador.php" method="POST">
        <input type="hidden" name="usuario_id" value="<?php echo $colaborador_id; ?>">
        <input type="hidden" name="nuevo_estado" value="<?php echo $colaborador['estado'] == 'activo' ? 'inactivo' : 'activo'; ?>">
        <button type="submit"><?php echo $colaborador['estado'] == 'activo' ? 'Desactivar Usuario' : 'Activar Usuario'; ?></button>
    </form>

    <a href="gestionar_colaboradores.php" style="display:block; margin-top:20px;">Volver a Gestión de Gestores</a>
</body>
</html>
