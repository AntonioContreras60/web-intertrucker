<?php
session_start();
include 'conexion.php'; // Conexión a la base de datos

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Verificar si el usuario está autenticado
if (!isset($_SESSION['usuario_id'])) {
    header("Location: inicio_sesion.php");
    exit();
}

// Obtener el ID del usuario de la sesión
$usuario_id = $_SESSION['usuario_id'];

// Verificar que se haya proporcionado un ID de porte
if (!isset($_POST['porte_id'])) {
    die("Error: No se proporcionó un ID de porte.");
}

$porte_id = $_POST['porte_id'];

// Iniciar transacción
$conn->begin_transaction();

try {
    // Insertar el cambio de titularidad en la tabla cambios_titularidad
    $sql_cambio = "INSERT INTO cambios_titularidad (usuario_id_1, usuario_id_2, porte_id, fecha) VALUES (?, ?, ?, NOW())";
    $stmt_cambio = $conn->prepare($sql_cambio);
    if (!$stmt_cambio) {
        throw new Exception("Error en la preparación de la consulta de cambio de titularidad: " . $conn->error);
    }
    $stmt_cambio->bind_param('iii', $usuario_id, $usuario_id, $porte_id);
    $stmt_cambio->execute();
    $stmt_cambio->close();

    // Actualizar el usuario receptor en la tabla seleccionados_oferta
    $sql_actualizar = "UPDATE seleccionados_oferta SET usuario_id = ? WHERE porte_id = ?";
    $stmt_actualizar = $conn->prepare($sql_actualizar);
    if (!$stmt_actualizar) {
        throw new Exception("Error en la preparación de la consulta de actualización de titularidad: " . $conn->error);
    }
    $stmt_actualizar->bind_param('ii', $usuario_id, $porte_id);
    $stmt_actualizar->execute();
    $stmt_actualizar->close();

    // Confirmar transacción
    $conn->commit();

    echo "<p>Titularidad del porte cambiada correctamente.</p>";
    echo "<a href='portes_nuevos_recibidos_todos.php'>Volver a Portes Recibidos</a>";
} catch (Exception $e) {
    // Revertir transacción en caso de error
    $conn->rollback();
    die("Error: " . $e->getMessage());
}

// Cerrar la conexión
$conn->close();
?>
