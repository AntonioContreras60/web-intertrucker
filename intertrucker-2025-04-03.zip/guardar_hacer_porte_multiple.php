<?php
session_start();
include 'conexion.php'; // Ajusta a tu archivo

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Verificar sesión
if (!isset($_SESSION['usuario_id'])) {
    die("Error: No hay usuario_id en la sesión.");
}
$usuario_id = $_SESSION['usuario_id'];

// 1. Recibir la lista de portes
if (!isset($_POST['porte_id']) || !is_array($_POST['porte_id'])) {
    die("Error: No se recibieron portes.");
}
$portes = $_POST['porte_id'];
if (count($portes)===0) {
    die("Error: Lista de portes vacía.");
}

// 2. Ver si seleccionaron un TÁNDEM existente
$tandem_existente = isset($_POST['tandem_existente']) ? trim($_POST['tandem_existente']) : '';

// 3. O si se crea un tren nuevo
$vehiculo_existente    = $_POST['vehiculo_existente']    ?? '';
$semi_remolque_existente = $_POST['semi_remolque_existente'] ?? '';
$remolque_existente    = $_POST['remolque_existente']    ?? '';
$camionero_existente   = $_POST['camionero_existente']   ?? '';

if (!$tandem_existente && !$vehiculo_existente && !$camionero_existente) {
    // Ni tándem ni vehículo+camionero => error
    die("No se seleccionó ni un tándem ni se creó un tren nuevo.");
}

// 4. Determinar tren_id y camionero_id final
$tren_id       = null;
$camionero_id  = null;
$fecha_actual  = date("Y-m-d H:i:s");

// ===== OPCIÓN A: TÁNDEM EXISTENTE =====
if ($tandem_existente !== '') {
    // Formato "tren_id|camionero_id"
    list($tren_id, $camionero_id) = explode('|', $tandem_existente);
    // Validar que sean numéricos
    $tren_id      = (int) $tren_id;
    $camionero_id = (int) $camionero_id;

    // Podrías verificar aquí si el tren y camionero efectivamente existen en DB
    // ...
    
// ===== OPCIÓN B: CREAR TREN NUEVO =====
} else {
    // Insertar un nuevo registro en `tren` (por ejemplo), obtener $tren_id
    // Podrías generar un nombre de tren random, o pedirlo en el formulario
    $tren_nombre = "Tren " . uniqid();
    $sql_new_tren = "INSERT INTO tren (tren_nombre) VALUES (?)";
    $stmt_tren = $conn->prepare($sql_new_tren);
    $stmt_tren->bind_param("s", $tren_nombre);
    $stmt_tren->execute();
    $tren_id = $stmt_tren->insert_id;
    $stmt_tren->close();

    // Asegurarnos de tener un camionero_id
    $camionero_id = (int) $camionero_existente;
    if ($camionero_id <= 0) {
        // Error: no eligieron un camionero
        die("No se eligió un camionero válido para el tren nuevo.");
    }
    // Insertar en tren_camionero
    $sql_tc = "INSERT INTO tren_camionero (tren_id, camionero_id, inicio_tren_camionero)
               VALUES (?, ?, ?)";
    $stmt_tc = $conn->prepare($sql_tc);
    $stmt_tc->bind_param("iis", $tren_id, $camionero_id, $fecha_actual);
    $stmt_tc->execute();
    $stmt_tc->close();

    // Crear las asociaciones de vehículo principal (cabeza/rigido) y semirremolque, etc., en tren_vehiculos
    if($vehiculo_existente){
        $veh_id = (int)$vehiculo_existente;
        if($veh_id>0){
            $sql_tv = "INSERT INTO tren_vehiculos (tren_id, vehiculo_id, inicio_vehiculo_tren)
                       VALUES (?, ?, ?)";
            $stmt_tv = $conn->prepare($sql_tv);
            $stmt_tv->bind_param("iis", $tren_id, $veh_id, $fecha_actual);
            $stmt_tv->execute();
            $stmt_tv->close();
        }
    }
    if($semi_remolque_existente){
        $semi_id = (int)$semi_remolque_existente;
        if($semi_id>0){
            $sql_tv2 = "INSERT INTO tren_vehiculos (tren_id, vehiculo_id, inicio_vehiculo_tren)
                        VALUES (?, ?, ?)";
            $stmt_tv2 = $conn->prepare($sql_tv2);
            $stmt_tv2->bind_param("iis", $tren_id, $semi_id, $fecha_actual);
            $stmt_tv2->execute();
            $stmt_tv2->close();
        }
    }
    if($remolque_existente){
        $rem_id = (int)$remolque_existente;
        if($rem_id>0){
            $sql_tv3 = "INSERT INTO tren_vehiculos (tren_id, vehiculo_id, inicio_vehiculo_tren)
                        VALUES (?, ?, ?)";
            $stmt_tv3 = $conn->prepare($sql_tv3);
            $stmt_tv3->bind_param("iis", $tren_id, $rem_id, $fecha_actual);
            $stmt_tv3->execute();
            $stmt_tv3->close();
        }
    }
}

// 5. Asignar cada porte al tren
//   - Insertar en `porte_tren` (o lo que uses), algo como (porte_id, tren_id, usuario_id, inicio_tren).
foreach($portes as $pid) {
    $pid_int = (int)$pid;

    // Para no duplicar si ya existe
    // Podrías ver si ya existe una fila con (porte_id, tren_id)
    // o directamente Insert. Depende de tu lógica
    $sql_insert_pt = "
        INSERT INTO porte_tren (porte_id, tren_id, usuario_id, inicio_tren)
        VALUES (?, ?, ?, ?)
    ";
    $stmt_pt = $conn->prepare($sql_insert_pt);
    $stmt_pt->bind_param("iiis", $pid_int, $tren_id, $usuario_id, $fecha_actual);
    $stmt_pt->execute();
    $stmt_pt->close();

    // Opcional: marcar la oferta en 'ofertas_varios' como 'en_tren' o algo
    $sql_upd = "
        UPDATE ofertas_varios
        SET estado_oferta = 'en_tren'
        WHERE porte_id = ?
          AND usuario_id = ?
          AND estado_oferta='asignado'
    ";
    $stmt_upd = $conn->prepare($sql_upd);
    $stmt_upd->bind_param("ii", $pid_int, $usuario_id);
    $stmt_upd->execute();
    $stmt_upd->close();
}

// 6. Redirigir
header("Location: portes_nuevos_recibidos.php?msg=portes_asignados");
exit;
