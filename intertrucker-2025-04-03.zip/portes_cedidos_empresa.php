<?php
session_start();
include 'conexion.php'; // Ajusta si tu archivo se llama distinto
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Verificamos que exista usuario_id (el tuyo) en la sesión
if (!isset($_SESSION['usuario_id'])) {
    die("Error: Falta usuario_id en la sesión.");
}
$usuarioSesion = $_SESSION['usuario_id'];

// Tomamos la empresa/transportista por GET
if (!isset($_GET['usuario_id'])) {
    die("Error: Falta usuario_id (empresa) en la URL.");
}
$empresaId = (int)$_GET['usuario_id'];

// Opcional: obtener nombre de la empresa/usuario
$stmtNombre = $conn->prepare("SELECT nombre_empresa FROM usuarios WHERE id=?");
$stmtNombre->bind_param("i", $empresaId);
$stmtNombre->execute();
$resNom = $stmtNombre->get_result();
$nombreEmpresa = "";
if ($filaNom = $resNom->fetch_assoc()) {
    $nombreEmpresa = $filaNom['nombre_empresa'];
}
$stmtNombre->close();

// Query para sacar los portes:
// - so.ofertante_id = tu ID => indica que fuiste tú quien asignó
// - so.usuario_id = la empresa => a quién asignaste
// - p.fecha_entrega >= CURDATE() => portes no finalizados aún
$sql = "
    SELECT 
      p.id AS porte_id,
      p.mercancia_descripcion,
      p.localizacion_recogida,
      p.fecha_recogida,
      p.localizacion_entrega,
      p.fecha_entrega
    FROM seleccionados_oferta so
    JOIN portes p ON so.porte_id = p.id
    WHERE so.ofertante_id = ?
      AND so.usuario_id = ?
      AND p.fecha_entrega >= CURDATE()
    ORDER BY p.fecha_entrega ASC
";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    die('Error preparando la consulta de portes: '.$conn->error);
}
$stmt->bind_param("ii", $usuarioSesion, $empresaId);
$stmt->execute();
$res = $stmt->get_result();

$portes = [];
while ($row = $res->fetch_assoc()) {
    $portes[] = $row;
}
$stmt->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Portes asignados a <?php echo htmlspecialchars($nombreEmpresa); ?></title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding:16px;
    }
    table {
      border-collapse: collapse;
      width: 100%;
      margin-top:16px;
    }
    th,td {
      border:1px solid #ccc;
      padding:8px;
    }
    th {
      background-color:#f2f2f2;
    }
    .btn {
      display:inline-block;
      padding:8px 12px;
      background:#007bff;
      color:#fff;
      text-decoration:none;
      border-radius:4px;
      margin-right:8px;
    }
  </style>
</head>
<body>

<?php include 'header.php'; ?>

<h1>Portes asignados a <?php echo htmlspecialchars($nombreEmpresa); ?></h1>

<div style="margin-bottom:16px;">
  <!-- Botón o enlace para volver al listado de empresas (portes_enviados_recibidos.php) -->
  <a href="portes_cedidos.php" class="btn" style="background:#6c757d;">
    &larr; Volver a Listado de Empresas
  </a>
</div>

<?php if (count($portes) > 0): ?>
  <table>
    <thead>
      <tr>
        <th>ID</th>
        <th>Mercancía</th>
        <th>Origen</th>
        <th>Fecha Recogida</th>
        <th>Destino</th>
        <th>Fecha Entrega</th>
        <th>Acciones</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach($portes as $p): ?>
      <tr>
        <td>#<?php echo htmlspecialchars($p['porte_id']); ?></td>
        <td><?php echo htmlspecialchars($p['mercancia_descripcion']); ?></td>
        <td><?php echo htmlspecialchars($p['localizacion_recogida']); ?></td>
        <td><?php echo htmlspecialchars($p['fecha_recogida']); ?></td>
        <td><?php echo htmlspecialchars($p['localizacion_entrega']); ?></td>
        <td><?php echo htmlspecialchars($p['fecha_entrega']); ?></td>
        <td>
          <!-- Botón Detalles -->
          <a href="detalle_porte.php?id=<?php echo $p['porte_id']; ?>" 
             class="btn" 
             style="background:#6c757d;"
             target="_blank">
            Detalles
          </a>
          <!-- Botón Recogida -->
          <a href="recogida_entrega_vista.php?porte_id=<?php echo $p['porte_id']; ?>&tipo_evento=recogida"
             class="btn"
             style="background-color:#ffc107; color:#000;"
             target="_blank">
            Recogida
          </a>
          <!-- Botón Entrega -->
          <a href="recogida_entrega_vista.php?porte_id=<?php echo $p['porte_id']; ?>&tipo_evento=entrega"
             class="btn"
             style="background-color:#17a2b8;"
             target="_blank">
            Entrega
          </a>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
<?php else: ?>
  <p>No hay portes pendientes para esta empresa (fecha de entrega < hoy o no existen).</p>
<?php endif; ?>
<br>
<br>

</body>
</html>
