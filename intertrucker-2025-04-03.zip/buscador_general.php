<?php
session_start();
include 'conexion.php'; // Incluye la conexión a la base de datos

// Verificar que el usuario esté autenticado
if (!isset($_SESSION['usuario_id'])) {
    echo "Error: Usuario no autenticado.";
    exit();
}

$usuario_id = $_SESSION['usuario_id'];
$search_term = isset($_GET['q']) ? $_GET['q'] : '';
$search_term = htmlspecialchars($search_term);

// Consulta SQL básica
// - Filtra por p.usuario_creador_id, so.usuario_id, so.ofertante_id
// - Busca sólo en mercancia_descripcion, localizacion_recogida, localizacion_entrega
// - No mostramos el ID en la tabla, pero sí lo seleccionamos para usarlo en la acción "Ver Detalles"
$sql = "
    SELECT 
        p.id, 
        p.mercancia_descripcion, 
        p.localizacion_recogida, 
        p.localizacion_entrega
    FROM portes p
    LEFT JOIN seleccionados_oferta so ON p.id = so.porte_id
    WHERE 
      (
        p.usuario_creador_id = ?
        OR so.usuario_id = ?
        OR so.ofertante_id = ?
      )
      AND (
        p.mercancia_descripcion    LIKE ?
        OR p.localizacion_recogida LIKE ?
        OR p.localizacion_entrega  LIKE ?
      )
    ORDER BY p.id DESC
";

// Preparar la consulta
$stmt = $conn->prepare($sql);
if (!$stmt) {
    die("Error al preparar la consulta: " . $conn->error);
}

// Parámetros para la consulta
$search_param = "%$search_term%";
// 3 ints + 3 strings => bind_param("iiisss", ...)
$stmt->bind_param(
    "iiisss",
    $usuario_id,
    $usuario_id,
    $usuario_id,
    $search_param,
    $search_param,
    $search_param
);

// Ejecutar la consulta
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Buscador General</title>
    <style>
      /* Ajusta tus estilos o enlaza un .css */
      body {
        margin: 20px;
        font-family: Arial, sans-serif;
      }
      .result-container {
        margin-top: 20px;
      }
      table {
        border-collapse: collapse;
        width: 100%;
        margin-top: 10px;
      }
      th, td {
        border: 1px solid #ccc;
        padding: 8px;
      }
      th {
        background-color: #f2f2f2;
      }
    </style>
</head>
<body>

  <?php include 'header.php'; ?>

  <div class="result-container">
      <h1>Resultados de la búsqueda para "<?php echo $search_term; ?>"</h1>

      <p>
        <strong>Nota:</strong> Esta búsqueda filtra únicamente por
        <em>mercancía, origen y destino.</em>
      </p>

      <!-- Formulario de búsqueda -->
      <form action="buscador_general.php" method="GET">
          <input 
              type="text"
              name="q"
              placeholder="Buscar por término..."
              value="<?php echo $search_term; ?>"
          />
          <button type="submit">Buscar</button>
      </form>

      <?php if ($result->num_rows > 0): ?>
          <h2>Resultados en Portes:</h2>
          <table>
              <thead>
                  <tr>
                      <th>Descripción (Mercancía)</th>
                      <th>Recogida (Origen)</th>
                      <th>Entrega (Destino)</th>
                      <th>Acciones</th>
                  </tr>
              </thead>
              <tbody>
                  <?php while ($row = $result->fetch_assoc()): ?>
                      <tr>
                          <td><?php echo htmlspecialchars($row['mercancia_descripcion']); ?></td>
                          <td><?php echo htmlspecialchars($row['localizacion_recogida']); ?></td>
                          <td><?php echo htmlspecialchars($row['localizacion_entrega']); ?></td>
                          <td>
                              <form action="detalle_porte.php" method="GET" style="display: inline;">
                                  <!-- No mostramos el ID, pero sí lo usamos internamente -->
                                  <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                  <button type="submit">Ver Detalles</button>
                              </form>
                          </td>
                      </tr>
                  <?php endwhile; ?>
              </tbody>
          </table>
      <?php else: ?>
          <p>No se encontraron portes relacionados con el término de búsqueda.</p>
      <?php endif; ?>

      <?php
      // Cerrar la consulta y conexión
      $stmt->close();
      $conn->close();
      ?>
  </div>

</body>
</html>
