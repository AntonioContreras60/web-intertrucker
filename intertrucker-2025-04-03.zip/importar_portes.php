<?php
/*****************************************************************************
 * importar_portes_seminteligente_tipo_porte.php
 *
 * - Sube un CSV (separador ;, primera fila = cabeceras).
 * - El usuario elige en el formulario si "tipo_porte" es 'propio' o 'recibido'
 *   y ese valor se asigna a todos los portes importados.
 * - Diccionario multilingüe + seminteligencia (fechas/horas/booleans).
 * - Lo que no encaja, va a 'observaciones'.
 *****************************************************************************/

// ---------------------------------------------------------------------------
// 1. Conexión a la base de datos
// ---------------------------------------------------------------------------
$dbHost = "db5016197746.hosting-data.io";
$dbUser = "dbu4085097";
$dbPass = "123intertruckerya";
$dbName = "dbs13181300";

$conn = new mysqli($dbHost, $dbUser, $dbPass, $dbName);
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}
echo "Conexión OK.<br>\n";

// ---------------------------------------------------------------------------
// 2. Diccionario para coincidencia literal (varios idiomas)
// ---------------------------------------------------------------------------
$mapaFijo = [
    "mercancia"                  => "mercancia_descripcion",
    "mercancia_descripcion"      => "mercancia_descripcion",
    "descripcion_mercancia"      => "mercancia_descripcion",
    "goods description"          => "mercancia_descripcion",
    "description marchandises"    => "mercancia_descripcion",
    "beschreibung ware"          => "mercancia_descripcion",
    "descricao mercadoria"       => "mercancia_descripcion",
    "货物描述"                     => "mercancia_descripcion",

    "tipo_camion"                => "tipo_camion",
    "truck type"                 => "tipo_camion",
    "tipo camion"                => "tipo_camion",
    "type camion"                => "tipo_camion",
    "tipo caminhão"              => "tipo_camion",
    "lkw typ"                    => "tipo_camion",
    "卡车类型"                      => "tipo_camion",

    // Booleans
    "adr"                        => "adr",
    "no_transbordos"             => "no_transbordos",
    "transfers_prohibited"       => "no_transbordos",
    "cadena_frio"                => "cadena_frio",
    "cold_chain"                 => "cadena_frio",
    "paletizado"                 => "paletizado",
    "palletized"                 => "paletizado",
    "intercambio_palets"         => "intercambio_palets",
    "palet_exchange"             => "intercambio_palets",
];

// ---------------------------------------------------------------------------
// 3. Columnas “semi-inteligentes”: (recogida/origen) y (entrega/destino)
// ---------------------------------------------------------------------------
$colsRecogida = ["recogida","origen","pickup","coleta","abholung","lieu collecte","pick-up"];
$colsEntrega  = ["entrega","destino","delivery","livraison","ziel","destination"];

// ---------------------------------------------------------------------------
// 4. Funciones de detección (fecha/hora/booleans)
// ---------------------------------------------------------------------------
function esFecha($str) {
    return (bool)preg_match("/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/", trim($str));
}
function esHora($str) {
    return (bool)preg_match("/^(\d{1,2}):(\d{1,2})(:\d{1,2})?$/", trim($str));
}
function formatearFecha($str) {
    if (preg_match("/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/", trim($str), $m)) {
        return $m[3]."-".$m[2]."-".$m[1];
    }
    return $str; 
}
function formatearHora($str) {
    if (preg_match("/^(\d{1,2}):(\d{1,2})(:\d{1,2})?$/", trim($str), $m)) {
        $hh = str_pad($m[1], 2, "0", STR_PAD_LEFT);
        $mm = str_pad($m[2], 2, "0", STR_PAD_LEFT);
        $ss = isset($m[4]) ? str_pad($m[4], 2, "0", STR_PAD_LEFT) : "00";
        return "$hh:$mm:$ss";
    }
    return $str;
}
function convertirBool($str) {
    $s = strtolower(trim($str));
    $listaSi = ["si","sí","yes","ja","oui","sim","true","1"];
    if (in_array($s, $listaSi)) {
        return 1;
    }
    $listaNo = ["no","0","false","nein","non","nao","não"];
    if (in_array($s, $listaNo)) {
        return 0;
    }
    return null; 
}

// ---------------------------------------------------------------------------
// 5. Procesar formulario
// ---------------------------------------------------------------------------
if (isset($_POST['importar']) && isset($_FILES['fichero_csv'])) {
    // El usuario ha elegido "propio" o "recibido"
    $tipoPorte = isset($_POST['tipo_porte']) ? $_POST['tipo_porte'] : 'propio';
    // Aseguramos que sea uno de los permitidos
    if (!in_array($tipoPorte, ['propio','recibido'])) {
        $tipoPorte = 'propio';
    }

    $tmpFile = $_FILES['fichero_csv']['tmp_name'];
    if (!is_uploaded_file($tmpFile)) {
        die("Error al subir el CSV.");
    }

    $handle = fopen($tmpFile, "r");
    if (!$handle) {
        die("No se pudo abrir el CSV.");
    }

    $cabeceras = fgetcsv($handle, 1000, ";");
    if (!$cabeceras) {
        die("CSV vacío o sin cabeceras.");
    }

    $cabNorm = [];
    foreach ($cabeceras as $i => $c) {
        $cabNorm[$i] = strtolower(trim($c));
    }

    $inserts_ok   = 0;
    $inserts_fail = 0;

    while (($fila = fgetcsv($handle, 1000, ";")) !== false) {
        $registro = [];
        $observ   = [];

        // Asignamos el tipo_porte elegido a cada fila
        $registro["tipo_porte"] = $tipoPorte;

        foreach ($cabNorm as $pos => $col) {
            $valor = isset($fila[$pos]) ? trim($fila[$pos]) : "";
            if ($valor === "") {
                continue;
            }

            // 1) diccionario literal
            if (isset($mapaFijo[$col])) {
                $campoBD = $mapaFijo[$col];
                // booleans
                if (in_array($campoBD, ["adr","no_transbordos","cadena_frio","paletizado","intercambio_palets"])) {
                    $b = convertirBool($valor);
                    if ($b !== null) {
                        $valor = $b;
                    } else {
                        $observ[] = "$col=$valor";
                        continue;
                    }
                }
                $registro[$campoBD] = $conn->real_escape_string($valor);
            }
            // 2) recogida/origen => fecha/hora/localizacion
            else if (in_array($col, $colsRecogida)) {
                if (esFecha($valor)) {
                    $registro["fecha_recogida"] = $conn->real_escape_string(formatearFecha($valor));
                } else if (esHora($valor)) {
                    $registro["recogida_hora_inicio"] = $conn->real_escape_string(formatearHora($valor));
                } else {
                    $registro["localizacion_recogida"] = $conn->real_escape_string($valor);
                }
            }
            // 3) entrega/destino => fecha/hora/localizacion
            else if (in_array($col, $colsEntrega)) {
                if (esFecha($valor)) {
                    $registro["fecha_entrega"] = $conn->real_escape_string(formatearFecha($valor));
                } else if (esHora($valor)) {
                    $registro["entrega_hora_inicio"] = $conn->real_escape_string(formatearHora($valor));
                } else {
                    $registro["localizacion_entrega"] = $conn->real_escape_string($valor);
                }
            }
            // 4) si no => a observaciones
            else {
                $observ[] = "$col=$valor";
            }
        }

        // Meter observaciones
        if (!empty($observ)) {
            if (!isset($registro["observaciones"])) {
                $registro["observaciones"] = "";
            }
            $registro["observaciones"] .= implode(" | ", $observ);
        }

        if (!isset($registro["observaciones"])) {
            $registro["observaciones"] = "";
        }

        // si no hay nada => skip
        if (empty($registro)) {
            continue;
        }

        // Insert
        $campos   = array_keys($registro);
        $sqlCampos= "`".implode("`,`",$campos)."`";
        $valsEsc  = [];
        foreach ($campos as $c) {
            $valsEsc[] = "'".$registro[$c]."'";
        }
        $sqlVals = implode(",", $valsEsc);

        $sql = "INSERT INTO portes ($sqlCampos) VALUES ($sqlVals)";
        if ($conn->query($sql) === TRUE) {
            $inserts_ok++;
        } else {
            $inserts_fail++;
            // echo "Error: ".$conn->error;
        }
    }

    fclose($handle);

    echo "<h2>Importación finalizada</h2>";
    echo "<p>Portes insertados: $inserts_ok</p>";
    echo "<p>Fallidos: $inserts_fail</p>";
    echo "<p><a href='importar_portes_seminteligente_tipo_porte.php'>Volver</a></p>";
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Importar Portes (Semi-Inteligente + tipo_porte)</title>
</head>
<body>
<h1>Importar Portes</h1>
<p>
    Este script:<br>
    - Usa un <strong>diccionario multilingüe</strong> para columnas.<br>
    - “recogida/origen” => fecha/hora/localización.<br>
    - “entrega/destino” => fecha/hora/localización.<br>
    - “adr,no_transbordos,cadena_frio,paletizado,intercambio_palets” => sí/no en varios idiomas => 1/0.<br>
    - Cualquier valor no reconocido => se concatena en <em>observaciones</em>.<br>
    - <strong>tipo_porte</strong> => “propio” o “recibido” (lo elige el usuario para todo el CSV).
</p>

<form method="post" enctype="multipart/form-data">
    <label>Archivo CSV (separado por ;, cabeceras en 1ª fila):</label><br>
    <input type="file" name="fichero_csv" required><br><br>

    <label>¿Tipo de porte?</label><br>
    <input type="radio" name="tipo_porte" value="propio"   checked> Propio <br>
    <input type="radio" name="tipo_porte" value="recibido"> Recibido <br><br>

    <button type="submit" name="importar">Importar CSV</button>
</form>

</body>
</html>
