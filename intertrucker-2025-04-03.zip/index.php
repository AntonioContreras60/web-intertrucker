<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>InterTrucker</title>
    <style>
        /* Estilo para la barra de navegación */
        header {
            background-color: #001C80; /* Color exacto del logotipo */
            padding: 20px 0; 
            text-align: center;
        }
        .logo img {
            max-width: 200px;
        }

        /* Estilo para el botón de iniciar sesión */
        .login-button {
            display: block;
            margin: 20px auto;
            padding: 15px 30px;
            font-size: 1.5em;
            color: #fff;
            background-color: #007bff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
            width: fit-content;
        }

        /* Estilo general de la página */
        main {
            padding: 20px;
        }

        h1 {
            color: #007bff;
            text-align: center;
        }
        @media screen and (max-width: 768px) {
            .detalle-movil {
                display: none;
            }
        }

    </style>
</head>
<body>
    <header>
        <div class="logo">
            <!-- Aquí se integra el logotipo -->
            <img src="imagenes/logos/logo2.png" alt="InterTrucker Logo">
        </div>
    </header>
    
    <main>
        <h1>Bienvenido a InterTrucker (web en construcción)</h1>

        <!-- Botón para iniciar sesión o darse de alta justo debajo del título -->
        <a href="/Perfil/inicio_sesion.php" class="login-button">Iniciar sesión o darse de alta</a>
        
        <h2>Ideas Generales:</h2>
        <p>•	Agiliza la gestión de portes tanto con tus contactos como con tus camiones.</p>
        <p>•	Facilita el registro de información en las recogidas y las entregas, y de facturas de gastos.</p>

        <div class="detalle-movil">
        <h2>InterTrucker al detalle:</h2>

        <p>En InterTrucker ofrecemos una plataforma diseñada para gestionar portes de manera eficiente, permitiendo a los usuarios crear, ofrecer, aceptar y asignar portes entre contactos o a camiones propios. Nuestro objetivo es mejorar la coordinación en el transporte y facilitar la gestión operativa tanto en la web como en la aplicación móvil.</p>

        <p>Los camioneros pueden registrar su llegada al lugar de carga o entrega, capturar fotos y videos de la mercancía y el CMR, añadir descripciones, registrar firmas de la otra parte y confirmar su salida del lugar. Además, tienen la posibilidad de registrar sus gastos adjuntando fotos de las facturas.</p>
        </div>
        <h2>Estructura de la plataforma</h2>
        <p>InterTrucker se divide en dos entornos clave:</p>
        <ul>
            <li><strong>La web</strong> (requiere conexión a Internet) → Ideal para la gestión de ofrecimientos y respuestas en tiempo real.</li>
            <li><strong>La app móvil</strong> (puede funcionar <strong>sin conexión</strong>) → Permite a los camioneros registrar datos incluso en zonas sin cobertura.</li>
        </ul>

<h2>Funcionalidades por plataforma</h2>

<h3>En la Web (Gestores)</h3>
<ul>
    <li><strong>Portes:</strong> Crear portes.</li>
    <li><strong>Compartir portes:</strong> Ofrecer portes a contactos y recibir ofrecimientos.</li>
    <li><strong>Asignar Portes:</strong> Asignar portes a camioneros de la empresa.</li>
    <li><strong>Trabajo en Equipo:</strong> Distribuir la gestión de portes entre distintos gestores.</li>
    <li><strong>Gestión interna:</strong> Administrar vehículos, camioneros y gestores.</li>
    <li><strong>Comunicación con camionero:</strong> Recibir toda la información recopilada por los camioneros.</li>
    <li><strong>Comunicación con expedidor:</strong> El expedidor recibe toda la información para preparar la documentación.</li>
    <li><strong>Facturas:</strong> Registrar facturas de gastos.</li>
    <li><strong>Almacén:</strong> Listado de regidas y entregas en el almacén propio.</li>
</ul>

<h3>En la App (Camioneros)</h3>
<ul>
    <li><strong>Sincronización:</strong> Acceso a toda la información de los portes asignados.</li>
    <li><strong>Recogidas y Entregas:</strong> Registro de recogidas y entregas con:
        <ul>
            <li>Geolocalización y fecha de llegada y salida de los lugares.</li>
            <li>Fotos y videos de la mercancía y documentos.</li>
            <li>Descripciones y firmas digitales.</li>
        </ul>
    </li>
    <li><strong>Búsqueda de direcciones:</strong> Búsqueda de direcciones en el mapa con solo presionar un botón.</li>
    <li><strong>Registro de facturas:</strong> Registro de facturas de gastos con evidencia fotográfica.</li>
</ul>

        

    </main>

    <!-- Incluye el pie de página desde un archivo separado -->
    <?php include 'footer.php'; ?>

    <!-- Importar el archivo SQLite Helper -->
    <script src="sqlite-helper.js"></script>
</body>
</html>
